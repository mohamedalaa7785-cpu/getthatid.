import { systemRouter } from "./_core/systemRouter";
import { router } from "./_core/trpc";
import { authRouter } from "./routers/auth";
import { numbersRouter } from "./routers/numbers";
import { interactionsRouter } from "./routers/interactions";
import { adminRouter } from "./routers/admin";
import { emailRouter } from "./routers/email";
import { notificationsRouter } from "./routers/notifications";
import { reputationRouter } from "./routers/reputation";
import { exportRouter } from "./routers/export";

export const appRouter = router({
  system: systemRouter,
  auth: authRouter,
  numbers: numbersRouter,
  interactions: interactionsRouter,
  admin: adminRouter,
  email: emailRouter,
  notifications: notificationsRouter,
  reputation: reputationRouter,
  export: exportRouter,
});

export type AppRouter = typeof appRouter;
