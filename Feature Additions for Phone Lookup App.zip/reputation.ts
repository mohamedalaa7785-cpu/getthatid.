import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import * as db from "../db";
import { TRPCError } from "@trpc/server";

export const reputationRouter = router({
  /**
   * Get user reputation
   */
  getReputation: publicProcedure
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      try {
        const reputation = await db.getUserReputation(input.userId);
        if (!reputation) {
          throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
        }

        return reputation;
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch reputation",
        });
      }
    }),

  /**
   * Get reputation badge
   */
  getBadge: publicProcedure
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      try {
        const reputation = await db.getUserReputation(input.userId);
        if (!reputation) {
          return { badge: "new", color: "gray" };
        }

        const score = reputation.reputationScore;
        if (score >= 1000) return { badge: "expert", color: "gold" };
        if (score >= 500) return { badge: "trusted", color: "blue" };
        if (score >= 100) return { badge: "contributor", color: "green" };
        if (score >= 10) return { badge: "active", color: "yellow" };
        return { badge: "new", color: "gray" };
      } catch (error) {
        return { badge: "new", color: "gray" };
      }
    }),

  /**
   * Get top contributors
   */
  getTopContributors: publicProcedure
    .input(z.object({ limit: z.number().default(10) }))
    .query(async ({ input }) => {
      try {
        const users = await db.getAllUsers();
        const sorted = users
          .sort((a, b) => (b.reputationScore || 0) - (a.reputationScore || 0))
          .slice(0, input.limit)
          .map((u) => ({
            id: u.id,
            name: u.name || "Anonymous",
            reputationScore: u.reputationScore || 0,
            accuracyRating: u.accuracyRating || 0,
          }));

        return sorted;
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch top contributors",
        });
      }
    }),

  /**
   * Get reputation leaderboard
   */
  getLeaderboard: publicProcedure
    .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      try {
        const users = await db.getAllUsers();
        const sorted = users
          .filter((u) => u.reputationScore && u.reputationScore > 0)
          .sort((a, b) => (b.reputationScore || 0) - (a.reputationScore || 0))
          .slice(input.offset, input.offset + input.limit)
          .map((u, index) => ({
            rank: input.offset + index + 1,
            id: u.id,
            name: u.name || "Anonymous",
            reputationScore: u.reputationScore || 0,
            accuracyRating: u.accuracyRating || 0,
            badge: getBadgeFromScore(u.reputationScore || 0),
          }));

        return {
          leaderboard: sorted,
          total: users.filter((u) => u.reputationScore && u.reputationScore > 0).length,
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch leaderboard",
        });
      }
    }),

  /**
   * Update reputation (admin only)
   */
  updateReputation: protectedProcedure
    .input(
      z.object({
        userId: z.number(),
        scoreChange: z.number(),
        accuracyChange: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const user = ctx.user;
      if (!user || user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can update reputation" });
      }

      try {
        await db.updateUserReputation(input.userId, input.scoreChange, input.accuracyChange || 0);

        await db.logActivity({
          userId: user.id,
          action: "reputation_updated",
          details: `Updated user ${input.userId} reputation by ${input.scoreChange}`,
          ipAddress: ctx.req.ip,
        });

        return { success: true };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update reputation",
        });
      }
    }),
});

function getBadgeFromScore(score: number): string {
  if (score >= 1000) return "expert";
  if (score >= 500) return "trusted";
  if (score >= 100) return "contributor";
  if (score >= 10) return "active";
  return "new";
}
