import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import {
  getAllUsers,
  getAllNumbers,
  blockUser,
  unblockUser,
  getActivityLogs,
  logActivity,
  getNumberInteractions,
  deleteNumber,
} from "../db";

/**
 * Admin-only procedure
 */
const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (!ctx.user || ctx.user.role !== "admin") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Only admins can access this resource",
    });
  }
  return next({ ctx });
});

export const adminRouter = router({
  /**
   * Get all users
   */
  getAllUsers: adminProcedure.query(async ({ ctx }) => {
    const users = await getAllUsers();
    return users.map((u) => ({
      id: u.id,
      email: u.email,
      name: u.name,
      phone: u.phone,
      role: u.role,
      isBlocked: u.isBlocked,
      createdAt: u.createdAt,
      lastSignedIn: u.lastSignedIn,
    }));
  }),

  /**
   * Block a user
   */
  blockUser: adminProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      await blockUser(input.userId);

      await logActivity({
        userId: ctx.user?.id,
        action: "block_user",
        details: `Admin blocked user ID: ${input.userId}`,
        ipAddress: ctx.req?.ip || undefined,
        createdAt: new Date(),
      });

      return { success: true };
    }),

  /**
   * Unblock a user
   */
  unblockUser: adminProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      await unblockUser(input.userId);

      await logActivity({
        userId: ctx.user?.id,
        action: "unblock_user",
        details: `Admin unblocked user ID: ${input.userId}`,
        ipAddress: ctx.req?.ip || undefined,
        createdAt: new Date(),
      });

      return { success: true };
    }),

  /**
   * Get all numbers with stats
   */
  getAllNumbers: adminProcedure.query(async ({ ctx }) => {
    const numbers = await getAllNumbers();
    return numbers.map((n) => ({
      id: n.id,
      phoneNumber: n.phoneNumber,
      name: n.name,
      category: n.category,
      agreeCount: n.agreeCount,
      disagreeCount: n.disagreeCount,
      reportCount: n.reportCount,
      createdAt: n.createdAt,
    }));
  }),

  /**
   * Delete a number (with cascading)
   */
  deleteNumber: adminProcedure
    .input(z.object({ numberId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      await deleteNumber(input.numberId);

      await logActivity({
        userId: ctx.user?.id,
        action: "delete_number",
        details: `Admin deleted number ID: ${input.numberId}`,
        ipAddress: ctx.req?.ip || undefined,
        createdAt: new Date(),
      });

      return { success: true };
    }),

  /**
   * Get statistics
   */
  getStats: adminProcedure.query(async ({ ctx }) => {
    const users = await getAllUsers();
    const numbers = await getAllNumbers();

    const totalUsers = users.length;
    const totalNumbers = numbers.length;
    const blockedUsers = users.filter((u) => u.isBlocked).length;
    const totalReports = numbers.reduce((sum, n) => sum + n.reportCount, 0);
    const totalAgreements = numbers.reduce((sum, n) => sum + n.agreeCount, 0);
    const totalDisagreements = numbers.reduce((sum, n) => sum + n.disagreeCount, 0);

    // Count by category
    const spamCount = numbers.filter((n) => n.category === "spam").length;
    const businessCount = numbers.filter((n) => n.category === "business").length;
    const personalCount = numbers.filter((n) => n.category === "personal").length;

    return {
      totalUsers,
      totalNumbers,
      blockedUsers,
      totalReports,
      totalAgreements,
      totalDisagreements,
      categoryBreakdown: {
        spam: spamCount,
        business: businessCount,
        personal: personalCount,
      },
    };
  }),

  /**
   * Get activity logs
   */
  getActivityLogs: adminProcedure
    .input(
      z.object({
        userId: z.number().optional(),
        limit: z.number().default(100),
      })
    )
    .query(async ({ input, ctx }) => {
      const logs = await getActivityLogs(input.userId);
      return logs.slice(0, input.limit);
    }),

  /**
   * Get number interactions (for reports)
   */
  getNumberInteractions: adminProcedure
    .input(z.object({ numberId: z.number() }))
    .query(async ({ input, ctx }) => {
      return await getNumberInteractions(input.numberId);
    }),
});
