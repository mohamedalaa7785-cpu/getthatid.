import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";
import * as db from "../db";

// Mock the database functions
vi.mock("../db", () => ({
  getNumberByPhoneNumber: vi.fn(),
  createNumber: vi.fn(),
  getAllNumbers: vi.fn(),
  getNumberById: vi.fn(),
  updateNumber: vi.fn(),
  deleteNumber: vi.fn(),
  logActivity: vi.fn(),
}));

function createMockContext(user?: any): TrpcContext {
  return {
    user,
    req: {
      ip: "127.0.0.1",
      protocol: "https",
      headers: {},
    } as any,
    res: {} as any,
  };
}

describe("numbers router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("search", () => {
    it("should find a phone number", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const mockNumber = {
        id: 1,
        phoneNumber: "(123) 456-7890",
        name: "Pizza Place",
        category: "business" as const,
        agreeCount: 5,
        disagreeCount: 1,
        reportCount: 0,
        createdAt: new Date(),
      };

      vi.mocked(db.getNumberByPhoneNumber).mockResolvedValue(mockNumber as any);

      const result = await caller.numbers.search({
        phoneNumber: "(123) 456-7890",
      });

      expect(result.found).toBe(true);
      expect(result.data?.name).toBe("Pizza Place");
      expect(db.getNumberByPhoneNumber).toHaveBeenCalled();
    });

    it("should return not found for unknown number", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      vi.mocked(db.getNumberByPhoneNumber).mockResolvedValue(null);

      const result = await caller.numbers.search({
        phoneNumber: "(999) 999-9999",
      });

      expect(result.found).toBe(false);
      expect(result.data).toBeNull();
    });

    it("should reject invalid phone number", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.numbers.search({
          phoneNumber: "invalid",
        })
      ).rejects.toThrow("Invalid phone number format");
    });
  });

  describe("add", () => {
    it("should add a new phone number when authenticated", async () => {
      const mockUser = {
        id: 1,
        email: "test@example.com",
        role: "user",
      };

      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);

      vi.mocked(db.getNumberByPhoneNumber).mockResolvedValue(null);
      vi.mocked(db.createNumber).mockResolvedValue({ insertId: 1 } as any);

      const result = await caller.numbers.add({
        phoneNumber: "(123) 456-7890",
        name: "Pizza Place",
        category: "business",
      });

      expect(result.success).toBe(true);
      expect(db.createNumber).toHaveBeenCalled();
      expect(db.logActivity).toHaveBeenCalled();
    });

    it("should reject adding duplicate number", async () => {
      const mockUser = {
        id: 1,
        email: "test@example.com",
        role: "user",
      };

      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);

      const existingNumber = {
        id: 1,
        phoneNumber: "(123) 456-7890",
        name: "Pizza Place",
        category: "business" as const,
      };

      vi.mocked(db.getNumberByPhoneNumber).mockResolvedValue(existingNumber as any);

      await expect(
        caller.numbers.add({
          phoneNumber: "(123) 456-7890",
          name: "Another Pizza",
          category: "business",
        })
      ).rejects.toThrow("Phone number already exists in database");
    });

    it("should reject add when not authenticated", async () => {
      const ctx = createMockContext(null);
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.numbers.add({
          phoneNumber: "(123) 456-7890",
          name: "Pizza Place",
          category: "business",
        })
      ).rejects.toThrow();
    });
  });

  describe("getAll", () => {
    it("should get all numbers when admin", async () => {
      const mockAdmin = {
        id: 1,
        email: "admin@example.com",
        role: "admin",
      };

      const ctx = createMockContext(mockAdmin);
      const caller = appRouter.createCaller(ctx);

      const mockNumbers = [
        {
          id: 1,
          phoneNumber: "(123) 456-7890",
          name: "Pizza Place",
          category: "business" as const,
        },
      ];

      vi.mocked(db.getAllNumbers).mockResolvedValue(mockNumbers as any);

      const result = await caller.numbers.getAll();

      expect(Array.isArray(result)).toBe(true);
      expect(db.getAllNumbers).toHaveBeenCalled();
    });

    it("should reject getAll when not admin", async () => {
      const mockUser = {
        id: 1,
        email: "user@example.com",
        role: "user",
      };

      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);

      await expect(caller.numbers.getAll()).rejects.toThrow(
        "Only admins can view all numbers"
      );
    });
  });

  describe("delete", () => {
    it("should delete a number when admin", async () => {
      const mockAdmin = {
        id: 1,
        email: "admin@example.com",
        role: "admin",
      };

      const ctx = createMockContext(mockAdmin);
      const caller = appRouter.createCaller(ctx);

      const mockNumber = {
        id: 1,
        phoneNumber: "(123) 456-7890",
        name: "Pizza Place",
        category: "business" as const,
      };

      vi.mocked(db.getNumberById).mockResolvedValue(mockNumber as any);
      vi.mocked(db.deleteNumber).mockResolvedValue({} as any);

      const result = await caller.numbers.delete({ id: 1 });

      expect(result.success).toBe(true);
      expect(db.deleteNumber).toHaveBeenCalledWith(1);
    });

    it("should reject delete when not admin", async () => {
      const mockUser = {
        id: 1,
        email: "user@example.com",
        role: "user",
      };

      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);

      await expect(caller.numbers.delete({ id: 1 })).rejects.toThrow(
        "Only admins can delete numbers"
      );
    });
  });
});
