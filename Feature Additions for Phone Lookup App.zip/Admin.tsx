import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Trash2, Lock, Unlock } from "lucide-react";

export default function Admin() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<"stats" | "numbers" | "users">("stats");

  const statsQuery = trpc.admin.getStats.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });
  const numbersQuery = trpc.admin.getAllNumbers.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });
  const usersQuery = trpc.admin.getAllUsers.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const deleteNumberMutation = trpc.admin.deleteNumber.useMutation();
  const blockUserMutation = trpc.admin.blockUser.useMutation();
  const unblockUserMutation = trpc.admin.unblockUser.useMutation();
  const utils = trpc.useUtils();

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center">
        <Card className="bg-gray-900 border-gray-700 p-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-gray-400 mb-6">You must be an admin to access this page.</p>
          <Link href="/">
            <a>
              <Button className="bg-white text-black hover:bg-gray-200">Back to Home</Button>
            </a>
          </Link>
        </Card>
      </div>
    );
  }

  const handleDeleteNumber = async (numberId: number) => {
    if (confirm("Are you sure you want to delete this number?")) {
      try {
        await deleteNumberMutation.mutateAsync({ numberId });
        utils.admin.getAllNumbers.invalidate();
      } catch (error) {
        console.error("Failed to delete number:", error);
      }
    }
  };

  const handleBlockUser = async (userId: number) => {
    try {
      await blockUserMutation.mutateAsync({ userId });
      utils.admin.getAllUsers.invalidate();
    } catch (error) {
      console.error("Failed to block user:", error);
    }
  };

  const handleUnblockUser = async (userId: number) => {
    try {
      await unblockUserMutation.mutateAsync({ userId });
      utils.admin.getAllUsers.invalidate();
    } catch (error) {
      console.error("Failed to unblock user:", error);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Navigation */}
      <nav className="border-b border-gray-800 py-4">
        <div className="max-w-6xl mx-auto px-4 flex justify-between items-center">
          <Link href="/">
            <a className="text-2xl font-bold">GET THAT ID</a>
          </Link>
          <div className="flex gap-6 items-center">
            <Link href="/">
              <a className="hover:text-gray-400">HOME</a>
            </Link>
            <span className="text-gray-400">Admin Panel</span>
          </div>
        </div>
      </nav>

      {/* Admin Panel */}
      <div className="flex-1 max-w-6xl mx-auto w-full py-8 px-4">
        <h1 className="text-4xl font-bold mb-8">Admin Panel</h1>

        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-gray-800">
          <button
            onClick={() => setActiveTab("stats")}
            className={`px-4 py-2 font-medium ${
              activeTab === "stats"
                ? "border-b-2 border-white"
                : "text-gray-400 hover:text-white"
            }`}
          >
            Statistics
          </button>
          <button
            onClick={() => setActiveTab("numbers")}
            className={`px-4 py-2 font-medium ${
              activeTab === "numbers"
                ? "border-b-2 border-white"
                : "text-gray-400 hover:text-white"
            }`}
          >
            Phone Numbers
          </button>
          <button
            onClick={() => setActiveTab("users")}
            className={`px-4 py-2 font-medium ${
              activeTab === "users"
                ? "border-b-2 border-white"
                : "text-gray-400 hover:text-white"
            }`}
          >
            Users
          </button>
        </div>

        {/* Statistics Tab */}
        {activeTab === "stats" && (
          <div>
            {statsQuery.isLoading ? (
              <p className="text-gray-400">Loading...</p>
            ) : statsQuery.data ? (
              <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <p className="text-gray-400 text-sm">Total Users</p>
                  <p className="text-3xl font-bold">{statsQuery.data.totalUsers}</p>
                </Card>
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <p className="text-gray-400 text-sm">Blocked Users</p>
                  <p className="text-3xl font-bold text-red-500">{statsQuery.data.blockedUsers}</p>
                </Card>
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <p className="text-gray-400 text-sm">Total Numbers</p>
                  <p className="text-3xl font-bold">{statsQuery.data.totalNumbers}</p>
                </Card>
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <p className="text-gray-400 text-sm">Total Reports</p>
                  <p className="text-3xl font-bold text-yellow-500">{statsQuery.data.totalReports}</p>
                </Card>
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <p className="text-gray-400 text-sm">Total Agreements</p>
                  <p className="text-3xl font-bold text-green-500">{statsQuery.data.totalAgreements}</p>
                </Card>
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <p className="text-gray-400 text-sm">Total Disagreements</p>
                  <p className="text-3xl font-bold text-red-500">{statsQuery.data.totalDisagreements}</p>
                </Card>
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <p className="text-gray-400 text-sm">Spam Numbers</p>
                  <p className="text-3xl font-bold">{statsQuery.data.categoryBreakdown.spam}</p>
                </Card>
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <p className="text-gray-400 text-sm">Business Numbers</p>
                  <p className="text-3xl font-bold">{statsQuery.data.categoryBreakdown.business}</p>
                </Card>
              </div>
            ) : null}
          </div>
        )}

        {/* Numbers Tab */}
        {activeTab === "numbers" && (
          <div>
            {numbersQuery.isLoading ? (
              <p className="text-gray-400">Loading...</p>
            ) : numbersQuery.data && numbersQuery.data.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b border-gray-700">
                    <tr>
                      <th className="text-left py-3 px-4">Phone Number</th>
                      <th className="text-left py-3 px-4">Name</th>
                      <th className="text-left py-3 px-4">Category</th>
                      <th className="text-left py-3 px-4">Agree</th>
                      <th className="text-left py-3 px-4">Disagree</th>
                      <th className="text-left py-3 px-4">Reports</th>
                      <th className="text-left py-3 px-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {numbersQuery.data.map((number) => (
                      <tr key={number.id} className="border-b border-gray-800 hover:bg-gray-900">
                        <td className="py-3 px-4">{number.phoneNumber}</td>
                        <td className="py-3 px-4">{number.name}</td>
                        <td className="py-3 px-4 capitalize">{number.category}</td>
                        <td className="py-3 px-4 text-green-500">{number.agreeCount}</td>
                        <td className="py-3 px-4 text-red-500">{number.disagreeCount}</td>
                        <td className="py-3 px-4 text-yellow-500">{number.reportCount}</td>
                        <td className="py-3 px-4">
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDeleteNumber(number.id)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            <Trash2 size={16} />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-400">No numbers found</p>
            )}
          </div>
        )}

        {/* Users Tab */}
        {activeTab === "users" && (
          <div>
            {usersQuery.isLoading ? (
              <p className="text-gray-400">Loading...</p>
            ) : usersQuery.data && usersQuery.data.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b border-gray-700">
                    <tr>
                      <th className="text-left py-3 px-4">Email</th>
                      <th className="text-left py-3 px-4">Name</th>
                      <th className="text-left py-3 px-4">Role</th>
                      <th className="text-left py-3 px-4">Status</th>
                      <th className="text-left py-3 px-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {usersQuery.data.map((u) => (
                      <tr key={u.id} className="border-b border-gray-800 hover:bg-gray-900">
                        <td className="py-3 px-4">{u.email}</td>
                        <td className="py-3 px-4">{u.name || "-"}</td>
                        <td className="py-3 px-4 capitalize">{u.role}</td>
                        <td className="py-3 px-4">
                          <span
                            className={
                              u.isBlocked
                                ? "text-red-500 font-medium"
                                : "text-green-500 font-medium"
                            }
                          >
                            {u.isBlocked ? "Blocked" : "Active"}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          {u.isBlocked ? (
                            <Button
                              size="sm"
                              onClick={() => handleUnblockUser(u.id)}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <Unlock size={16} />
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              onClick={() => handleBlockUser(u.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              <Lock size={16} />
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-400">No users found</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
