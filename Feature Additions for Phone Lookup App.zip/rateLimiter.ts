import * as db from "../db";

export interface RateLimitOptions {
  windowMs?: number; // Time window in milliseconds (default: 60000 = 1 minute)
  maxRequests?: number; // Max requests per window (default: 100)
  keyGenerator?: (userId: number | null, ipAddress: string) => string;
  skipSuccessfulRequests?: boolean;
  skipFailedRequests?: boolean;
}

const DEFAULT_OPTIONS: Required<RateLimitOptions> = {
  windowMs: 60000,
  maxRequests: 100,
  keyGenerator: (userId, ip) => `${userId || "anon"}:${ip}`,
  skipSuccessfulRequests: false,
  skipFailedRequests: false,
};

export class RateLimiter {
  private options: Required<RateLimitOptions>;

  constructor(options: RateLimitOptions = {}) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
  }

  async checkLimit(
    userId: number | null,
    ipAddress: string,
    endpoint: string
  ): Promise<{ allowed: boolean; remaining: number; resetAt?: Date }> {
    try {
      const result = await db.checkRateLimit(
        userId,
        ipAddress,
        endpoint,
        this.options.maxRequests,
        this.options.windowMs
      );

      return {
        allowed: result.allowed,
        remaining: result.remaining,
      };
    } catch (error) {
      console.error("[RateLimit] Error checking rate limit:", error);
      // Allow request if rate limit check fails
      return { allowed: true, remaining: this.options.maxRequests };
    }
  }
}

// Export singleton instance with default settings
export const rateLimiter = new RateLimiter();

// Export factory for custom rate limiters
export function createRateLimiter(options: RateLimitOptions = {}) {
  return new RateLimiter(options);
}

// Specific rate limiters for different endpoints
export const authLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000, // 15 minutes
  maxRequests: 5, // 5 requests per 15 minutes
});

export const searchLimiter = createRateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 30, // 30 searches per minute
});

export const interactionLimiter = createRateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 50, // 50 interactions per minute
});

export const apiLimiter = createRateLimiter({
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 100, // 100 requests per minute
});
