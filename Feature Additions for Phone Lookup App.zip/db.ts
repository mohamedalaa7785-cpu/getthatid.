import { eq, and, desc, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, InsertNumber, InsertInteraction, InsertActivityLog, users, numbers, interactions, activityLog } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ User Functions ============

export async function createUser(user: InsertUser) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(users).values(user);
  return result;
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUser(id: number, updates: Partial<InsertUser>) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.update(users).set(updates).where(eq(users.id, id));
  return result;
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.select().from(users);
}

export async function blockUser(id: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.update(users).set({ isBlocked: 1 }).where(eq(users.id, id));
}

export async function unblockUser(id: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.update(users).set({ isBlocked: 0 }).where(eq(users.id, id));
}

// ============ Phone Number Functions ============

export async function createNumber(number: InsertNumber) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(numbers).values(number);
  return result;
}

export async function getNumberByPhoneNumber(phoneNumber: string) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.select().from(numbers).where(eq(numbers.phoneNumber, phoneNumber)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getNumberById(id: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.select().from(numbers).where(eq(numbers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllNumbers() {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.select().from(numbers);
}

export async function updateNumber(id: number, updates: Partial<InsertNumber>) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.update(numbers).set(updates).where(eq(numbers.id, id));
}

export async function deleteNumber(id: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.delete(numbers).where(eq(numbers.id, id));
}

// ============ Interaction Functions ============

export async function createInteraction(interaction: InsertInteraction) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(interactions).values(interaction);
  return result;
}

export async function getUserInteraction(userId: number, numberId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.select().from(interactions).where(
    and(eq(interactions.userId, userId), eq(interactions.numberId, numberId))
  ).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateInteraction(id: number, action: string) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.update(interactions).set({ action: action as any }).where(eq(interactions.id, id));
}

export async function getNumberInteractions(numberId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.select().from(interactions).where(eq(interactions.numberId, numberId));
}

// ============ Activity Log Functions ============

export async function logActivity(log: InsertActivityLog) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot log activity: database not available");
    return;
  }

  try {
    await db.insert(activityLog).values(log);
  } catch (error) {
    console.error("[Database] Failed to log activity:", error);
  }
}

export async function getActivityLogs(userId?: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  if (userId) {
    return await db.select().from(activityLog).where(eq(activityLog.userId, userId));
  }
  return await db.select().from(activityLog);
}


// ============ Notification Functions ============

export async function createNotification(notification: any) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const { notifications } = await import("../drizzle/schema");
  const result = await db.insert(notifications).values(notification);
  return result;
}

export async function getUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const { notifications } = await import("../drizzle/schema");
  return await db.select().from(notifications).where(eq(notifications.userId, userId));
}

export async function markNotificationAsRead(notificationId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const { notifications } = await import("../drizzle/schema");
  return await db.update(notifications).set({ read: 1 }).where(eq(notifications.id, notificationId));
}

// ============ Rate Limit Functions ============

export async function checkRateLimit(userId: number | null, ipAddress: string, endpoint: string, limit: number = 100, windowMs: number = 60000) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const { rateLimits } = await import("../drizzle/schema");
  const now = new Date();
  const resetAt = new Date(now.getTime() + windowMs);

  // Get or create rate limit record
  let record = await db.select().from(rateLimits).where(
    and(
      userId ? eq(rateLimits.userId, userId) : isNull(rateLimits.userId),
      eq(rateLimits.ipAddress, ipAddress),
      eq(rateLimits.endpoint, endpoint)
    )
  ).limit(1);

  if (record.length > 0) {
    const existing = record[0];
    if (new Date(existing.resetAt) < now) {
      // Reset window expired, create new record
      await db.update(rateLimits).set({ requestCount: 1, resetAt }).where(eq(rateLimits.id, existing.id));
      return { allowed: true, remaining: limit - 1 };
    } else {
      // Within window, check limit
      const newCount = existing.requestCount + 1;
      if (newCount > limit) {
        return { allowed: false, remaining: 0 };
      }
      await db.update(rateLimits).set({ requestCount: newCount }).where(eq(rateLimits.id, existing.id));
      return { allowed: true, remaining: limit - newCount };
    }
  } else {
    // Create new record
    await db.insert(rateLimits).values({
      userId: userId || undefined,
      ipAddress,
      endpoint,
      requestCount: 1,
      resetAt,
    });
    return { allowed: true, remaining: limit - 1 };
  }
}

// ============ Reputation Functions ============

export async function updateUserReputation(userId: number, scoreChange: number, accuracyChange: number = 0) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const user = await getUserById(userId);
  if (!user) return;

  const newScore = Math.max(0, (user.reputationScore || 0) + scoreChange);
  const newAccuracy = Math.max(0, (user.accuracyRating || 0) + accuracyChange);

  return await updateUser(userId, {
    reputationScore: newScore,
    accuracyRating: newAccuracy,
  });
}

export async function getUserReputation(userId: number) {
  const user = await getUserById(userId);
  if (!user) return null;

  return {
    reputationScore: user.reputationScore || 0,
    accuracyRating: user.accuracyRating || 0,
  };
}

// ============ Email Verification Functions ============

export async function generateVerificationToken(userId: number) {
  const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  await updateUser(userId, { verificationToken: token });
  return token;
}

export async function verifyEmail(userId: number, token: string) {
  const user = await getUserById(userId);
  if (!user || user.verificationToken !== token) {
    return false;
  }

  await updateUser(userId, {
    emailVerified: 1,
    verificationToken: null,
  });
  return true;
}

export async function isEmailVerified(userId: number) {
  const user = await getUserById(userId);
  return user?.emailVerified === 1;
}


export async function getAllInteractions() {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.select().from(interactions);
}
