CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` text NOT NULL,
	`type` enum('info','warning','success','error') NOT NULL DEFAULT 'info',
	`read` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `rateLimits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`ipAddress` varchar(45) NOT NULL,
	`endpoint` varchar(255) NOT NULL,
	`requestCount` int NOT NULL DEFAULT 1,
	`resetAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `rateLimits_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `emailVerified` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `verificationToken` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `reputationScore` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `accuracyRating` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `notificationsEnabled` int DEFAULT 1 NOT NULL;--> statement-breakpoint
CREATE INDEX `userIdx` ON `notifications` (`userId`);--> statement-breakpoint
CREATE INDEX `readIdx` ON `notifications` (`read`);--> statement-breakpoint
CREATE INDEX `userIdx` ON `rateLimits` (`userId`);--> statement-breakpoint
CREATE INDEX `ipIdx` ON `rateLimits` (`ipAddress`);--> statement-breakpoint
CREATE INDEX `endpointIdx` ON `rateLimits` (`endpoint`);