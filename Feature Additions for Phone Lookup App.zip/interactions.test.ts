import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";
import * as db from "../db";

// Mock the database functions
vi.mock("../db", () => ({
  getUserInteraction: vi.fn(),
  createInteraction: vi.fn(),
  updateInteraction: vi.fn(),
  getNumberById: vi.fn(),
  updateNumber: vi.fn(),
  getNumberInteractions: vi.fn(),
  logActivity: vi.fn(),
}));

function createMockContext(user?: any): TrpcContext {
  return {
    user,
    req: {
      ip: "127.0.0.1",
      protocol: "https",
      headers: {},
    } as any,
    res: {} as any,
  };
}

describe("interactions router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("setAction", () => {
    it("should create a new interaction when user hasn't interacted before", async () => {
      const mockUser = {
        id: 1,
        email: "test@example.com",
        role: "user",
      };

      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);

      const mockNumber = {
        id: 1,
        phoneNumber: "(123) 456-7890",
        name: "Pizza Place",
        category: "business" as const,
        agreeCount: 5,
        disagreeCount: 1,
        reportCount: 0,
      };

      vi.mocked(db.getUserInteraction).mockResolvedValue(null);
      vi.mocked(db.getNumberById).mockResolvedValue(mockNumber as any);
      vi.mocked(db.createInteraction).mockResolvedValue({ insertId: 1 } as any);
      vi.mocked(db.updateNumber).mockResolvedValue({} as any);

      const result = await caller.interactions.setAction({
        numberId: 1,
        action: "agree",
      });

      expect(result.success).toBe(true);
      expect(db.createInteraction).toHaveBeenCalled();
      expect(db.updateNumber).toHaveBeenCalled();
    });

    it("should update existing interaction when user changes action", async () => {
      const mockUser = {
        id: 1,
        email: "test@example.com",
        role: "user",
      };

      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);

      const mockNumber = {
        id: 1,
        phoneNumber: "(123) 456-7890",
        name: "Pizza Place",
        category: "business" as const,
        agreeCount: 5,
        disagreeCount: 1,
        reportCount: 0,
      };

      const existingInteraction = {
        id: 1,
        userId: 1,
        numberId: 1,
        action: "agree" as const,
        createdAt: new Date(),
      };

      vi.mocked(db.getUserInteraction).mockResolvedValue(existingInteraction as any);
      vi.mocked(db.getNumberById).mockResolvedValue(mockNumber as any);
      vi.mocked(db.updateInteraction).mockResolvedValue({} as any);
      vi.mocked(db.updateNumber).mockResolvedValue({} as any);

      const result = await caller.interactions.setAction({
        numberId: 1,
        action: "disagree",
      });

      expect(result.success).toBe(true);
      expect(db.updateInteraction).toHaveBeenCalled();
      expect(db.updateNumber).toHaveBeenCalled();
    });

    it("should return success if user performs same action again", async () => {
      const mockUser = {
        id: 1,
        email: "test@example.com",
        role: "user",
      };

      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);

      const existingInteraction = {
        id: 1,
        userId: 1,
        numberId: 1,
        action: "agree" as const,
        createdAt: new Date(),
      };

      vi.mocked(db.getUserInteraction).mockResolvedValue(existingInteraction as any);

      const result = await caller.interactions.setAction({
        numberId: 1,
        action: "agree",
      });

      expect(result.success).toBe(true);
      expect(result.message).toContain("already recorded");
    });

    it("should reject setAction when not authenticated", async () => {
      const ctx = createMockContext(null);
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.interactions.setAction({
          numberId: 1,
          action: "agree",
        })
      ).rejects.toThrow();
    });

    it("should reject setAction for non-existent number", async () => {
      const mockUser = {
        id: 1,
        email: "test@example.com",
        role: "user",
      };

      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);

      vi.mocked(db.getNumberById).mockResolvedValue(null);

      await expect(
        caller.interactions.setAction({
          numberId: 999,
          action: "agree",
        })
      ).rejects.toThrow("Phone number not found");
    });
  });

  describe("getByNumber", () => {
    it("should get user's interaction with a number", async () => {
      const mockUser = {
        id: 1,
        email: "test@example.com",
        role: "user",
      };

      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);

      const mockInteraction = {
        id: 1,
        userId: 1,
        numberId: 1,
        action: "agree" as const,
        createdAt: new Date(),
      };

      vi.mocked(db.getUserInteraction).mockResolvedValue(mockInteraction as any);

      const result = await caller.interactions.getByNumber({ numberId: 1 });

      expect(result).toBeDefined();
      expect(result?.action).toBe("agree");
    });

    it("should return null if user hasn't interacted", async () => {
      const mockUser = {
        id: 1,
        email: "test@example.com",
        role: "user",
      };

      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);

      vi.mocked(db.getUserInteraction).mockResolvedValue(null);

      const result = await caller.interactions.getByNumber({ numberId: 1 });

      expect(result).toBeNull();
    });

    it("should reject getByNumber when not authenticated", async () => {
      const ctx = createMockContext(null);
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.interactions.getByNumber({ numberId: 1 })
      ).rejects.toThrow();
    });
  });
});
