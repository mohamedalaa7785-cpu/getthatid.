CREATE TABLE `activityLog` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`action` varchar(100) NOT NULL,
	`details` text,
	`ipAddress` varchar(45),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activityLog_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `interactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`numberId` int NOT NULL,
	`action` enum('agree','disagree','report') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `interactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `userNumberUnique` UNIQUE(`userId`,`numberId`)
);
--> statement-breakpoint
CREATE TABLE `numbers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phoneNumber` varchar(20) NOT NULL,
	`name` text NOT NULL,
	`category` enum('spam','business','personal') NOT NULL,
	`agreeCount` int NOT NULL DEFAULT 0,
	`disagreeCount` int NOT NULL DEFAULT 0,
	`reportCount` int NOT NULL DEFAULT 0,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `numbers_id` PRIMARY KEY(`id`),
	CONSTRAINT `numbers_phoneNumber_unique` UNIQUE(`phoneNumber`)
);
--> statement-breakpoint
ALTER TABLE `users` DROP INDEX `users_openId_unique`;--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `email` varchar(320) NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `passwordHash` text NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `isBlocked` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_email_unique` UNIQUE(`email`);--> statement-breakpoint
CREATE INDEX `userIdx` ON `activityLog` (`userId`);--> statement-breakpoint
CREATE INDEX `actionIdx` ON `activityLog` (`action`);--> statement-breakpoint
CREATE INDEX `userIdx` ON `interactions` (`userId`);--> statement-breakpoint
CREATE INDEX `numberIdx` ON `interactions` (`numberId`);--> statement-breakpoint
CREATE INDEX `createdByIdx` ON `numbers` (`createdBy`);--> statement-breakpoint
CREATE INDEX `phoneNumberIdx` ON `numbers` (`phoneNumber`);--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `openId`;--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `loginMethod`;