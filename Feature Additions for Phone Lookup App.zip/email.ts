import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import * as db from "../db";
import { TRPCError } from "@trpc/server";

export const emailRouter = router({
  /**
   * Send verification email
   */
  sendVerificationEmail: protectedProcedure.mutation(async ({ ctx }) => {
    const user = ctx.user;
    if (!user) {
      throw new TRPCError({ code: "UNAUTHORIZED", message: "Not authenticated" });
    }

    if (user.emailVerified) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Email already verified" });
    }

    try {
      const token = await db.generateVerificationToken(user.id);
      
      // In production, send actual email here
      console.log(`[Email] Verification token for ${user.email}: ${token}`);
      
      // For now, return the token in development
      const isDev = process.env.NODE_ENV !== "production";
      
      await db.logActivity({
        userId: user.id,
        action: "email_verification_requested",
        details: `Verification email sent to ${user.email}`,
        ipAddress: ctx.req.ip,
      });

      return {
        success: true,
        message: "Verification email sent",
        token: isDev ? token : undefined,
      };
    } catch (error) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to send verification email",
      });
    }
  }),

  /**
   * Verify email with token
   */
  verifyEmail: protectedProcedure
    .input(z.object({ token: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const user = ctx.user;
      if (!user) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Not authenticated" });
      }

      if (user.emailVerified) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Email already verified" });
      }

      const verified = await db.verifyEmail(user.id, input.token);
      if (!verified) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Invalid or expired verification token" });
      }

      await db.logActivity({
        userId: user.id,
        action: "email_verified",
        details: `Email ${user.email} verified`,
        ipAddress: ctx.req.ip,
      });

      return {
        success: true,
        message: "Email verified successfully",
      };
    }),

  /**
   * Check if email is verified
   */
  isVerified: protectedProcedure.query(async ({ ctx }) => {
    const user = ctx.user;
    if (!user) {
      throw new TRPCError({ code: "UNAUTHORIZED", message: "Not authenticated" });
    }

    const isVerified = await db.isEmailVerified(user.id);
    return { isVerified };
  }),
});
