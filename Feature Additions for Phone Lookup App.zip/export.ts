import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import * as db from "../db";
import { TRPCError } from "@trpc/server";

export const exportRouter = router({
  /**
   * Export numbers as CSV
   */
  exportNumbers: protectedProcedure
    .input(z.object({ format: z.enum(["csv", "json"]).default("csv") }))
    .query(async ({ ctx, input }) => {
      const user = ctx.user;
      if (!user || user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can export data" });
      }

      try {
        const numbers = await db.getAllNumbers();

        if (input.format === "json") {
          return {
            format: "json",
            data: JSON.stringify(numbers, null, 2),
            filename: `numbers-${new Date().toISOString().split("T")[0]}.json`,
          };
        }

        // CSV format
        const headers = ["ID", "Phone Number", "Name", "Category", "Agree Count", "Disagree Count", "Report Count", "Created At"];
        const rows = numbers.map((n: any) => [
          n.id,
          n.phoneNumber,
          n.name,
          n.category,
          n.agreeCount,
          n.disagreeCount,
          n.reportCount,
          n.createdAt,
        ]);

        const csv = [headers, ...rows].map((row: any) => row.map((cell: any) => `"${cell}"`).join(",")).join("\n");

        return {
          format: "csv",
          data: csv,
          filename: `numbers-${new Date().toISOString().split("T")[0]}.csv`,
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to export numbers",
        });
      }
    }),

  /**
   * Export users as CSV
   */
  exportUsers: protectedProcedure
    .input(z.object({ format: z.enum(["csv", "json"]).default("csv") }))
    .query(async ({ ctx, input }) => {
      const user = ctx.user;
      if (!user || user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can export data" });
      }

      try {
        const users = await db.getAllUsers();

        if (input.format === "json") {
          return {
            format: "json",
            data: JSON.stringify(
              users.map((u: any) => ({
                id: u.id,
                email: u.email,
                name: u.name,
                phone: u.phone,
                role: u.role,
                isBlocked: u.isBlocked,
                reputationScore: u.reputationScore,
                accuracyRating: u.accuracyRating,
                createdAt: u.createdAt,
              })),
              null,
              2
            ),
            filename: `users-${new Date().toISOString().split("T")[0]}.json`,
          };
        }

        // CSV format
        const headers = ["ID", "Email", "Name", "Phone", "Role", "Blocked", "Reputation", "Accuracy", "Created At"];
        const rows = users.map((u: any) => [
          u.id,
          u.email,
          u.name || "",
          u.phone || "",
          u.role,
          u.isBlocked ? "Yes" : "No",
          u.reputationScore || 0,
          u.accuracyRating || 0,
          u.createdAt,
        ]);

        const csv = [headers, ...rows].map((row: any) => row.map((cell: any) => `"${cell}"`).join(",")).join("\n");

        return {
          format: "csv",
          data: csv,
          filename: `users-${new Date().toISOString().split("T")[0]}.csv`,
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to export users",
        });
      }
    }),

  /**
   * Export interactions as CSV
   */
  exportInteractions: protectedProcedure
    .input(z.object({ format: z.enum(["csv", "json"]).default("csv") }))
    .query(async ({ ctx, input }) => {
      const user = ctx.user;
      if (!user || user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can export data" });
      }

      try {
        const interactions = await db.getAllInteractions();

        if (input.format === "json") {
          return {
            format: "json",
            data: JSON.stringify(interactions, null, 2),
            filename: `interactions-${new Date().toISOString().split("T")[0]}.json`,
          };
        }

        // CSV format
        const headers = ["ID", "User ID", "Number ID", "Action", "Created At"];
        const rows = interactions.map((i: any) => [i.id, i.userId, i.numberId, i.action, i.createdAt]);

        const csv = [headers, ...rows].map((row: any) => row.map((cell: any) => `"${cell}"`).join(",")).join("\n");

        return {
          format: "csv",
          data: csv,
          filename: `interactions-${new Date().toISOString().split("T")[0]}.csv`,
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to export interactions",
        });
      }
    }),

  /**
   * Get analytics summary
   */
  getAnalytics: protectedProcedure.query(async ({ ctx }) => {
    const user = ctx.user;
    if (!user || user.role !== "admin") {
      throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can view analytics" });
    }

    try {
      const users = await db.getAllUsers();
      const numbers = await db.getAllNumbers();
      const interactions = await db.getAllInteractions();

      const totalUsers = users.length;
      const totalNumbers = numbers.length;
      const totalInteractions = interactions.length;
      const blockedUsers = users.filter((u: any) => u.isBlocked).length;
      const verifiedUsers = users.filter((u: any) => u.emailVerified).length;

      const categoryBreakdown = numbers.reduce(
        (acc: any, n: any) => {
          acc[n.category] = (acc[n.category] || 0) + 1;
          return acc;
        },
        {}
      );

      const actionBreakdown = interactions.reduce(
        (acc: any, i: any) => {
          acc[i.action] = (acc[i.action] || 0) + 1;
          return acc;
        },
        {}
      );

      const avgReputation = users.length > 0 ? users.reduce((sum: number, u: any) => sum + (u.reputationScore || 0), 0) / users.length : 0;

      return {
        totalUsers,
        totalNumbers,
        totalInteractions,
        blockedUsers,
        verifiedUsers,
        categoryBreakdown,
        actionBreakdown,
        avgReputation: Math.round(avgReputation),
      };
    } catch (error) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to fetch analytics",
      });
    }
  }),
});
