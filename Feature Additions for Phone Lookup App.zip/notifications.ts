import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import * as db from "../db";
import { TRPCError } from "@trpc/server";

export const notificationsRouter = router({
  /**
   * Get user notifications
   */
  getNotifications: protectedProcedure
    .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }).optional())
    .query(async ({ ctx, input }) => {
      const user = ctx.user;
      if (!user) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Not authenticated" });
      }

      try {
        const notifications = await db.getUserNotifications(user.id);
        const limited = notifications.slice(input?.offset || 0, (input?.offset || 0) + (input?.limit || 20));
        const unreadCount = notifications.filter((n: any) => !n.read).length;

        return {
          notifications: limited,
          unreadCount,
          total: notifications.length,
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch notifications",
        });
      }
    }),

  /**
   * Mark notification as read
   */
  markAsRead: protectedProcedure
    .input(z.object({ notificationId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const user = ctx.user;
      if (!user) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Not authenticated" });
      }

      try {
        await db.markNotificationAsRead(input.notificationId);
        return { success: true };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to mark notification as read",
        });
      }
    }),

  /**
   * Create notification (internal use)
   */
  create: protectedProcedure
    .input(
      z.object({
        userId: z.number(),
        title: z.string(),
        content: z.string(),
        type: z.enum(["info", "warning", "success", "error"]).default("info"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const user = ctx.user;
      if (!user || user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only admins can create notifications" });
      }

      try {
        await db.createNotification({
          userId: input.userId,
          title: input.title,
          content: input.content,
          type: input.type,
        });

        return { success: true };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create notification",
        });
      }
    }),

  /**
   * Toggle notification preferences
   */
  togglePreferences: protectedProcedure
    .input(z.object({ enabled: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const user = ctx.user;
      if (!user) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Not authenticated" });
      }

      try {
        await db.updateUser(user.id, { notificationsEnabled: input.enabled ? 1 : 0 });

        await db.logActivity({
          userId: user.id,
          action: "notification_preferences_updated",
          details: `Notifications ${input.enabled ? "enabled" : "disabled"}`,
          ipAddress: ctx.req.ip,
        });

        return { success: true };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update notification preferences",
        });
      }
    }),
});
