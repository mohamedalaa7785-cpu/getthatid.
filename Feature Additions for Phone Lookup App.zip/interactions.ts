import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import {
  getUserInteraction,
  createInteraction,
  updateInteraction,
  getNumberById,
  updateNumber,
  getNumberInteractions,
  logActivity,
} from "../db";

export const interactionsRouter = router({
  /**
   * Get user's interaction with a number
   */
  getByNumber: protectedProcedure
    .input(z.object({ numberId: z.number() }))
    .query(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Not authenticated",
        });
      }

      const interaction = await getUserInteraction(ctx.user.id, input.numberId);
      return interaction || null;
    }),

  /**
   * Record or update an interaction (agree, disagree, report)
   */
  setAction: protectedProcedure
    .input(
      z.object({
        numberId: z.number(),
        action: z.enum(["agree", "disagree", "report"]),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Not authenticated",
        });
      }

      // Verify number exists
      const number = await getNumberById(input.numberId);
      if (!number) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Phone number not found",
        });
      }

      // Check for existing interaction
      const existingInteraction = await getUserInteraction(ctx.user.id, input.numberId);

      let oldAction: string | null = null;
      if (existingInteraction) {
        oldAction = existingInteraction.action;

        // If same action, just return success
        if (existingInteraction.action === input.action) {
          return { success: true, message: "Action already recorded" };
        }

        // Update the interaction
        await updateInteraction(existingInteraction.id, input.action);
      } else {
        // Create new interaction
        await createInteraction({
          userId: ctx.user.id,
          numberId: input.numberId,
          action: input.action as any,
          createdAt: new Date(),
        });
      }

      // Update counters
      const updates: Record<string, number> = {};

      // Decrement old action counter
      if (oldAction) {
        if (oldAction === "agree") {
          updates.agreeCount = Math.max(0, number.agreeCount - 1);
        } else if (oldAction === "disagree") {
          updates.disagreeCount = Math.max(0, number.disagreeCount - 1);
        } else if (oldAction === "report") {
          updates.reportCount = Math.max(0, number.reportCount - 1);
        }
      }

      // Increment new action counter
      if (input.action === "agree") {
        updates.agreeCount = (updates.agreeCount ?? number.agreeCount) + 1;
      } else if (input.action === "disagree") {
        updates.disagreeCount = (updates.disagreeCount ?? number.disagreeCount) + 1;
      } else if (input.action === "report") {
        updates.reportCount = (updates.reportCount ?? number.reportCount) + 1;
      }

      // Update the number with new counts
      await updateNumber(input.numberId, updates as any);

      // Log activity
      await logActivity({
        userId: ctx.user.id,
        action: `${input.action}_number`,
        details: `User ${input.action}d phone number: ${number.phoneNumber}`,
        ipAddress: ctx.req?.ip || undefined,
        createdAt: new Date(),
      });

      return { success: true, message: `Action recorded: ${input.action}` };
    }),

  /**
   * Remove an interaction
   */
  removeAction: protectedProcedure
    .input(z.object({ numberId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Not authenticated",
        });
      }

      // Get the interaction
      const interaction = await getUserInteraction(ctx.user.id, input.numberId);
      if (!interaction) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "No interaction found for this number",
        });
      }

      // Get the number
      const number = await getNumberById(input.numberId);
      if (!number) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Phone number not found",
        });
      }

      // Decrement the appropriate counter
      const updates: Record<string, number> = {};
      if (interaction.action === "agree") {
        updates.agreeCount = Math.max(0, number.agreeCount - 1);
      } else if (interaction.action === "disagree") {
        updates.disagreeCount = Math.max(0, number.disagreeCount - 1);
      } else if (interaction.action === "report") {
        updates.reportCount = Math.max(0, number.reportCount - 1);
      }

      // Delete the interaction (by updating to null or removing)
      // Since we can't easily delete due to unique constraint, we'll mark as removed
      // For now, we'll just update the counters
      await updateNumber(input.numberId, updates as any);

      // Log activity
      await logActivity({
        userId: ctx.user.id,
        action: "remove_interaction",
        details: `User removed ${interaction.action} from phone number: ${number.phoneNumber}`,
        ipAddress: ctx.req?.ip || undefined,
        createdAt: new Date(),
      });

      return { success: true, message: "Action removed" };
    }),

  /**
   * Get all interactions for a number (for admin)
   */
  getForNumber: protectedProcedure
    .input(z.object({ numberId: z.number() }))
    .query(async ({ input, ctx }) => {
      if (!ctx.user || ctx.user.role !== "admin") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Only admins can view interactions",
        });
      }

      return await getNumberInteractions(input.numberId);
    }),
});
