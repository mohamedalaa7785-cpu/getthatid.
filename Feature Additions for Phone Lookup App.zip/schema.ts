import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, unique, index } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with phone number and activity tracking.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: text("passwordHash").notNull(),
  name: text("name"),
  phone: varchar("phone", { length: 20 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  isBlocked: int("isBlocked").default(0).notNull(),
  emailVerified: int("emailVerified").default(0).notNull(),
  verificationToken: varchar("verificationToken", { length: 255 }),
  reputationScore: int("reputationScore").default(0).notNull(),
  accuracyRating: int("accuracyRating").default(0).notNull(),
  notificationsEnabled: int("notificationsEnabled").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Phone numbers table with community data.
 */
export const numbers = mysqlTable("numbers", {
  id: int("id").autoincrement().primaryKey(),
  phoneNumber: varchar("phoneNumber", { length: 20 }).notNull().unique(),
  name: text("name").notNull(),
  category: mysqlEnum("category", ["spam", "business", "personal"]).notNull(),
  agreeCount: int("agreeCount").default(0).notNull(),
  disagreeCount: int("disagreeCount").default(0).notNull(),
  reportCount: int("reportCount").default(0).notNull(),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  createdByIdx: index("createdByIdx").on(table.createdBy),
  phoneNumberIdx: index("phoneNumberIdx").on(table.phoneNumber),
}));

export type Number = typeof numbers.$inferSelect;
export type InsertNumber = typeof numbers.$inferInsert;

/**
 * User interactions with phone numbers.
 * Tracks agree, disagree, and report actions.
 */
export const interactions = mysqlTable("interactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  numberId: int("numberId").notNull(),
  action: mysqlEnum("action", ["agree", "disagree", "report"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userNumberUnique: unique("userNumberUnique").on(table.userId, table.numberId),
  userIdx: index("userIdx").on(table.userId),
  numberIdx: index("numberIdx").on(table.numberId),
}));

export type Interaction = typeof interactions.$inferSelect;
export type InsertInteraction = typeof interactions.$inferInsert;

/**
 * Activity log for security and auditing.
 */
export const activityLog = mysqlTable("activityLog", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  action: varchar("action", { length: 100 }).notNull(),
  details: text("details"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("userIdx").on(table.userId),
  actionIdx: index("actionIdx").on(table.action),
}));

export type ActivityLog = typeof activityLog.$inferSelect;
export type InsertActivityLog = typeof activityLog.$inferInsert;

/**
 * Notifications table for user notifications.
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  type: mysqlEnum("type", ["info", "warning", "success", "error"]).default("info").notNull(),
  read: int("read").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("userIdx").on(table.userId),
  readIdx: index("readIdx").on(table.read),
}));

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Rate limit tracking for security.
 */
export const rateLimits = mysqlTable("rateLimits", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  ipAddress: varchar("ipAddress", { length: 45 }).notNull(),
  endpoint: varchar("endpoint", { length: 255 }).notNull(),
  requestCount: int("requestCount").default(1).notNull(),
  resetAt: timestamp("resetAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("userIdx").on(table.userId),
  ipIdx: index("ipIdx").on(table.ipAddress),
  endpointIdx: index("endpointIdx").on(table.endpoint),
}));

export type RateLimit = typeof rateLimits.$inferSelect;
export type InsertRateLimit = typeof rateLimits.$inferInsert;
