import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";

export default function AddNumber() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const [phoneNumber, setPhoneNumber] = useState("");
  const [name, setName] = useState("");
  const [category, setCategory] = useState<"spam" | "business" | "personal">("personal");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const addNumberMutation = trpc.numbers.add.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center">
        <Card className="bg-gray-900 border-gray-700 p-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-gray-400 mb-6">You must be logged in to add a number.</p>
          <Link href="/login">
            <a>
              <Button className="bg-white text-black hover:bg-gray-200">Login</Button>
            </a>
          </Link>
        </Card>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!phoneNumber || !name) {
      setError("Please fill in all required fields");
      return;
    }

    setIsLoading(true);
    try {
      await addNumberMutation.mutateAsync({ phoneNumber, name, category });
      // Redirect to home after successful addition
      setLocation("/");
    } catch (err: any) {
      setError(err.message || "Failed to add number");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Navigation */}
      <nav className="border-b border-gray-800 py-4">
        <div className="max-w-6xl mx-auto px-4 flex justify-between items-center">
          <Link href="/">
            <a className="text-2xl font-bold">GET THAT ID</a>
          </Link>
          <div className="flex gap-6 items-center">
            <Link href="/">
              <a className="hover:text-gray-400">HOME</a>
            </Link>
            <Link href="/profile">
              <a className="hover:text-gray-400">PROFILE</a>
            </Link>
          </div>
        </div>
      </nav>

      {/* Add Number Form */}
      <div className="flex-1 flex items-center justify-center py-20">
        <Card className="bg-gray-900 border-gray-700 p-8 w-full max-w-md">
          <h1 className="text-3xl font-bold mb-6 text-center">Add Phone Number</h1>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Phone Number *</label>
              <Input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="(123) 456-7890"
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Name / Description *</label>
              <Input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Pizza Place, Spam Caller"
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full bg-gray-800 border border-gray-700 text-white rounded px-3 py-2"
              >
                <option value="personal">Personal</option>
                <option value="business">Business</option>
                <option value="spam">Spam</option>
              </select>
            </div>

            {error && <p className="text-red-500 text-sm">{error}</p>}

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-white text-black hover:bg-gray-200"
            >
              {isLoading ? "Adding..." : "Add Number"}
            </Button>
          </form>

          <p className="text-center text-gray-400 mt-6 text-sm">
            <Link href="/">
              <a className="text-white underline hover:text-gray-300">Back to home</a>
            </Link>
          </p>
        </Card>
      </div>
    </div>
  );
}
