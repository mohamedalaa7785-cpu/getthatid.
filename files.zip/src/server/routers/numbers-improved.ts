import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import {
  getNumberByPhoneNumber,
  createNumber,
  getAllNumbers,
  getNumberById,
  updateNumber,
  deleteNumber,
  logActivity,
} from "../db";
import { isValidPhoneNumber, formatPhoneNumber } from "../auth";
import { sanitizeString, validateInput } from "@/utils/sanitize";

export const numbersRouter = router({
  /**
   * Search for a phone number with validation
   */
  search: publicProcedure
    .input(z.object({ phoneNumber: z.string().trim() }))
    .query(async ({ input }) => {
      const validation = validateInput(input.phoneNumber, "phone");
      if (!validation.valid) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: validation.error || "Invalid phone number",
        });
      }

      const formatted = formatPhoneNumber(input.phoneNumber);
      const number = await getNumberByPhoneNumber(formatted);

      if (!number) {
        return { found: false, data: null };
      }

      return {
        found: true,
        data: {
          id: number.id,
          phoneNumber: number.phoneNumber,
          name: number.name,
          category: number.category,
          agreeCount: number.agreeCount,
          disagreeCount: number.disagreeCount,
          reportCount: number.reportCount,
          createdAt: number.createdAt,
        },
      };
    }),

  /**
   * Advanced search with pagination
   */
  advancedSearch: publicProcedure
    .input(
      z.object({
        query: z.string().optional(),
        category: z.enum(["spam", "business", "personal"]).optional(),
        sortBy: z
          .enum(["recent", "popular", "reported"])
          .default("recent"),
        limit: z.number().int().min(1).max(100).default(20),
        offset: z.number().int().min(0).default(0),
      })
    )
    .query(async ({ input }) => {
      try {
        let numbers = await getAllNumbers();

        // Filter by category
        if (input.category) {
          numbers = numbers.filter((n: any) => n.category === input.category);
        }

        // Filter by query
        if (input.query) {
          const lowerQuery = input.query.toLowerCase().trim();
          numbers = numbers.filter(
            (n: any) =>
              n.name.toLowerCase().includes(lowerQuery) ||
              n.phoneNumber.includes(lowerQuery)
          );
        }

        // Sort
        switch (input.sortBy) {
          case "popular":
            numbers.sort(
              (a: any, b: any) => (b.agreeCount || 0) - (a.agreeCount || 0)
            );
            break;
          case "reported":
            numbers.sort(
              (a: any, b: any) => (b.reportCount || 0) - (a.reportCount || 0)
            );
            break;
          case "recent":
          default:
            numbers.sort(
              (a: any, b: any) =>
                new Date(b.createdAt).getTime() -
                new Date(a.createdAt).getTime()
            );
        }

        // Paginate
        const total = numbers.length;
        const paginated = numbers.slice(
          input.offset,
          input.offset + input.limit
        );

        return {
          results: paginated,
          total,
          limit: input.limit,
          offset: input.offset,
          hasMore: input.offset + input.limit < total,
          pages: Math.ceil(total / input.limit),
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to search numbers",
        });
      }
    }),

  /**
   * Add a new phone number
   */
  add: protectedProcedure
    .input(
      z.object({
        phoneNumber: z.string().trim(),
        name: z.string().trim().min(1).max(255),
        category: z.enum(["spam", "business", "personal"]),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Not authenticated",
        });
      }

      // Validate inputs
      const phoneValidation = validateInput(input.phoneNumber, "phone");
      if (!phoneValidation.valid) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: phoneValidation.error,
        });
      }

      const nameValidation = validateInput(input.name, "text");
      if (!nameValidation.valid) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: nameValidation.error,
        });
      }

      const formatted = formatPhoneNumber(input.phoneNumber);
      const sanitizedName = sanitizeString(input.name);

      // Check if number already exists
      const existing = await getNumberByPhoneNumber(formatted);
      if (existing) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "Phone number already exists in database",
        });
      }

      // Create the number
      await createNumber({
        phoneNumber: formatted,
        name: sanitizedName,
        category: input.category,
        agreeCount: 0,
        disagreeCount: 0,
        reportCount: 0,
        createdBy: ctx.user.id,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      // Log activity
      await logActivity({
        userId: ctx.user.id,
        action: "add_number",
        details: `Added phone number: ${formatted}`,
        ipAddress: ctx.req?.ip || undefined,
        createdAt: new Date(),
      });

      return {
        success: true,
        message: "Phone number added successfully",
      };
    }),

  /**
   * Get all numbers (for admin)
   */
  getAll: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user || ctx.user.role !== "admin") {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "Only admins can view all numbers",
      });
    }

    return await getAllNumbers();
  }),

  /**
   * Get number by ID
   */
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const number = await getNumberById(input.id);
      if (!number) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Phone number not found",
        });
      }

      return number;
    }),

  /**
   * Get trending numbers
   */
  getTrending: publicProcedure
    .input(z.object({ limit: z.number().int().min(1).max(50).default(10) }))
    .query(async ({ input }) => {
      try {
        const numbers = await getAllNumbers();
        const trending = numbers
          .sort((a: any, b: any) => {
            const aScore = (a.agreeCount || 0) + (a.reportCount || 0) * 2;
            const bScore = (b.agreeCount || 0) + (b.reportCount || 0) * 2;
            return bScore - aScore;
          })
          .slice(0, input.limit);

        return trending;
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch trending numbers",
        });
      }
    }),
});