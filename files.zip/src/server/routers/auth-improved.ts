import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import {
  getUserByEmail,
  createUser,
  updateUser,
  logActivity,
} from "../db";
import {
  hashPassword,
  verifyPassword,
  isValidEmail,
  isValidPassword,
  formatPhoneNumber,
} from "../auth";
import { validateInput } from "@/utils/sanitize";

export const authRouter = router({
  /**
   * Sign up
   */
  signup: publicProcedure
    .input(
      z.object({
        email: z.string().trim(),
        password: z.string(),
        name: z.string().trim().optional(),
        phone: z.string().trim().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Validate email
      const emailValidation = validateInput(input.email, "email");
      if (!emailValidation.valid) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: emailValidation.error,
        });
      }

      // Validate password
      const passwordValidation = validateInput(input.password, "password");
      if (!passwordValidation.valid) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: passwordValidation.error,
        });
      }

      // Validate phone if provided
      if (input.phone) {
        const phoneValidation = validateInput(input.phone, "phone");
        if (!phoneValidation.valid) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: phoneValidation.error,
          });
        }
      }

      // Check if email already exists
      const existing = await getUserByEmail(input.email);
      if (existing) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "Email already registered",
        });
      }

      // Create user
      const passwordHash = hashPassword(input.password);
      const formattedPhone = input.phone ? formatPhoneNumber(input.phone) : null;

      await createUser({
        email: input.email,
        passwordHash,
        name: input.name || null,
        phone: formattedPhone,
        role: "user",
        isBlocked: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      });

      // Log activity
      await logActivity({
        action: "user_signup",
        details: `New user signed up: ${input.email}`,
        ipAddress: ctx.req?.ip || undefined,
        createdAt: new Date(),
      });

      return {
        success: true,
        message: "Account created successfully. Please login.",
      };
    }),

  /**
   * Login
   */
  login: publicProcedure
    .input(
      z.object({
        email: z.string().trim(),
        password: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const user = await getUserByEmail(input.email);

      if (!user || !verifyPassword(input.password, user.passwordHash)) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid email or password",
        });
      }

      if (user.isBlocked) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Your account has been blocked",
        });
      }

      // Update last signed in
      await updateUser(user.id, {
        lastSignedIn: new Date(),
      });

      // Log activity
      await logActivity({
        userId: user.id,
        action: "user_login",
        details: `User logged in`,
        ipAddress: ctx.req?.ip || undefined,
        createdAt: new Date(),
      });

      return {
        success: true,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          phone: user.phone,
          role: user.role,
        },
      };
    }),

  /**
   * Get current user
   */
  me: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "Not authenticated",
      });
    }

    return {
      id: ctx.user.id,
      email: ctx.user.email,
      name: ctx.user.name,
      phone: ctx.user.phone,
      role: ctx.user.role,
      createdAt: ctx.user.createdAt,
    };
  }),

  /**
   * Update profile
   */
  updateProfile: protectedProcedure
    .input(
      z.object({
        name: z.string().trim().optional(),
        phone: z.string().trim().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Not authenticated",
        });
      }

      // Validate inputs if provided
      if (input.name) {
        const nameValidation = validateInput(input.name, "text");
        if (!nameValidation.valid) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: nameValidation.error,
          });
        }
      }

      if (input.phone) {
        const phoneValidation = validateInput(input.phone, "phone");
        if (!phoneValidation.valid) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: phoneValidation.error,
          });
        }
      }

      const formattedPhone = input.phone ? formatPhoneNumber(input.phone) : undefined;

      await updateUser(ctx.user.id, {
        name: input.name,
        phone: formattedPhone,
        updatedAt: new Date(),
      });

      // Log activity
      await logActivity({
        userId: ctx.user.id,
        action: "profile_updated",
        details: "User updated their profile",
        ipAddress: ctx.req?.ip || undefined,
        createdAt: new Date(),
      });

      return { success: true, message: "Profile updated successfully" };
    }),

  /**
   * Logout
   */
  logout: protectedProcedure.mutation(async ({ ctx }) => {
    if (ctx.user) {
      await logActivity({
        userId: ctx.user.id,
        action: "user_logout",
        details: "User logged out",
        ipAddress: ctx.req?.ip || undefined,
        createdAt: new Date(),
      });
    }

    return { success: true };
  }),
});