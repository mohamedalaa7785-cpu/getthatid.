/**
 * Environment Configuration
 */

export const ENV = {
  // API Configuration
  API_URL: import.meta.env.VITE_API_URL || "http://localhost:3000",
  API_TIMEOUT: 30000,

  // App Configuration
  APP_NAME: "Get That ID",
  APP_VERSION: "1.0.0",

  // Feature Flags
  FEATURES: {
    SEARCH: true,
    TRENDING: true,
    ADMIN: true,
    NOTIFICATIONS: true,
    REPUTATION: true,
    EXPORT: true,
  },

  // Search Configuration
  SEARCH: {
    DEBOUNCE_MS: 300,
    MIN_QUERY_LENGTH: 2,
    MAX_RESULTS: 50,
    DEFAULT_LIMIT: 20,
  },

  // Pagination
  PAGINATION: {
    DEFAULT_PAGE_SIZE: 10,
    MAX_PAGE_SIZE: 100,
  },

  // Rate Limiting
  RATE_LIMITS: {
    SEARCH_PER_MINUTE: 30,
    INTERACTION_PER_MINUTE: 50,
    LOGIN_ATTEMPTS_PER_HOUR: 5,
  },

  // Validation Rules
  VALIDATION: {
    MIN_PASSWORD_LENGTH: 6,
    MAX_PASSWORD_LENGTH: 128,
    MIN_NAME_LENGTH: 1,
    MAX_NAME_LENGTH: 255,
    PHONE_MAX_LENGTH: 20,
  },

  // UI Configuration
  UI: {
    THEME: "dark" as const,
    ANIMATION_DURATION_MS: 300,
    TOAST_DURATION_MS: 5000,
  },

  // Development
  DEBUG: import.meta.env.DEV,
  NODE_ENV: import.meta.env.MODE,
};

export default ENV;