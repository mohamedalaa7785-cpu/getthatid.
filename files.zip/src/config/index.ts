// Application Configuration

export const config = {
  // App
  app: {
    name: "Get That ID",
    version: "1.0.0",
    description: "Premium caller identification service",
    author: "HAMO",
  },

  // API
  api: {
    baseUrl: process.env.REACT_APP_API_URL || "http://localhost:3000",
    timeout: 30000,
  },

  // Search
  search: {
    debounceDelay: 300,
    minQueryLength: 2,
    maxResults: 50,
    defaultLimit: 20,
  },

  // Pagination
  pagination: {
    defaultPageSize: 10,
    maxPageSize: 100,
  },

  // Rate Limiting
  rateLimit: {
    searchPerMinute: 30,
    interactionPerMinute: 50,
    loginAttemptsPerHour: 5,
  },

  // Validation
  validation: {
    minPasswordLength: 6,
    maxPasswordLength: 128,
    minNameLength: 1,
    maxNameLength: 255,
    phoneNumberMaxLength: 20,
  },

  // Features
  features: {
    enableSearch: true,
    enableTrending: true,
    enableAdmin: true,
    enableNotifications: true,
    enableReputation: true,
    enableExport: true,
  },

  // UI
  ui: {
    theme: "dark",
    animationDuration: 300,
    toastDuration: 5000,
  },
};

export default config;