import { useState } from "react";
import { useLanguageStore } from "@/hooks/useLanguage";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Mail, Phone, MapPin, Send } from "lucide-react";

export default function Contact() {
  const { language } = useLanguageStore();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Send email logic here
    console.log("Form submitted:", formData);
    setSubmitted(true);
    setTimeout(() => {
      setFormData({ name: "", email: "", subject: "", message: "" });
      setSubmitted(false);
    }, 3000);
  };

  return (
    <div>
      <Navbar />

      {/* Hero */}
      <section className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-gray-900 dark:to-gray-800 flex items-center pt-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <h1 className="text-5xl font-bold mb-6">
            {language === "en" ? "Get In Touch" : "اتصل بنا"}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl">
            {language === "en"
              ? "Have a question? We'd love to hear from you."
              : "لديك سؤال؟ نود أن نسمع منك."}
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div>
              <h2 className="text-3xl font-bold mb-8">
                {language === "en" ? "Contact Information" : "معلومات التواصل"}
              </h2>

              <div className="space-y-6">
                <div className="flex gap-4">
                  <Mail className="w-6 h-6 text-primary-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold">{language === "en" ? "Email" : "البريد الإلكتروني"}</h3>
                    <a href="mailto:info@example.com" className="text-gray-600 dark:text-gray-400 hover:text-primary-600">
                      info@example.com
                    </a>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Phone className="w-6 h-6 text-primary-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold">{language === "en" ? "Phone" : "الهاتف"}</h3>
                    <a href="tel:+201234567890" className="text-gray-600 dark:text-gray-400 hover:text-primary-600">
                      +20 123 456 7890
                    </a>
                  </div>
                </div>

                <div className="flex gap-4">
                  <MapPin className="w-6 h-6 text-primary-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold">{language === "en" ? "Address" : "العنوان"}</h3>
                    <p className="text-gray-600 dark:text-gray-400">Cairo, Egypt</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Form */}
            <div>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    {language === "en" ? "Name" : "الاسم"}
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-600"
                    placeholder={language === "en" ? "Your name" : "اسمك"}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    {language === "en" ? "Email" : "البريد الإلكتروني"}
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-600"
                    placeholder={language === "en" ? "your@email.com" : "بريدك@example.com"}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    {language === "en" ? "Subject" : "الموضوع"}
                  </label>
                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-600"
                    placeholder={language === "en" ? "Subject" : "الموضوع"}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    {language === "en" ? "Message" : "الرسالة"}
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-600 resize-none"
                    placeholder={language === "en" ? "Your message" : "رسالتك"}
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition flex items-center justify-center gap-2"
                >
                  <Send size={20} />
                  {language === "en" ? "Send Message" : "إرسال الرسالة"}
                </button>

                {submitted && (
                  <div className="p-4 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 rounded-lg">
                    {language === "en" ? "Message sent successfully!" : "تم إرسال الرسالة بنجاح!"}
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}