import { Link } from "wouter";
import { useLanguageStore } from "@/hooks/useLanguage";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Home, ArrowLeft } from "lucide-react";

export default function NotFound() {
  const { language } = useLanguageStore();

  return (
    <div>
      <Navbar />

      <section className="min-h-screen flex items-center justify-center bg-white dark:bg-gray-800">
        <div className="text-center px-4">
          <div className="text-9xl font-bold text-primary-600 mb-4">404</div>
          <h1 className="text-4xl font-bold mb-4">
            {language === "en" ? "Page Not Found" : "الصفحة غير موجودة"}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8 max-w-2xl">
            {language === "en"
              ? "Sorry, the page you're looking for doesn't exist."
              : "آسف، الصفحة التي تبحث عنها غير موجودة."}
          </p>

          <div className="flex gap-4 justify-center">
            <Link href="/">
              <a className="px-8 py-3 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition flex items-center gap-2">
                <Home size={20} />
                {language === "en" ? "Go Home" : "اذهب للرئيسية"}
              </a>
            </Link>
            <button
              onClick={() => window.history.back()}
              className="px-8 py-3 border-2 border-primary-600 text-primary-600 dark:text-primary-400 rounded-lg font-medium hover:bg-primary-50 dark:hover:bg-primary-900/20 transition flex items-center gap-2"
            >
              <ArrowLeft size={20} />
              {language === "en" ? "Go Back" : "عودة"}
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}