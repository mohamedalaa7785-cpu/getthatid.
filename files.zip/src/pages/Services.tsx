import { useLanguageStore } from "@/hooks/useLanguage";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Code, Smartphone, Globe, BarChart3, Shield, Zap } from "lucide-react";

export default function Services() {
  const { language } = useLanguageStore();

  const services = [
    {
      icon: Globe,
      title: language === "en" ? "Web Development" : "تطوير المواقع",
      description: language === "en" ? "Custom websites built with modern technologies" : "مواقع مخصصة مبنية بتقنيات حديثة",
    },
    {
      icon: Smartphone,
      title: language === "en" ? "Mobile Apps" : "تطبيقات الموبايل",
      description: language === "en" ? "Native and cross-platform mobile applications" : "تطبيقات موبايل محلية وعابرة للمنصات",
    },
    {
      icon: Code,
      title: language === "en" ? "Web Design" : "تصميم المواقع",
      description: language === "en" ? "Beautiful and user-friendly designs" : "تصاميم جميلة وسهلة الاستخدام",
    },
    {
      icon: BarChart3,
      title: language === "en" ? "SEO Optimization" : "تحسين محركات البحث",
      description: language === "en" ? "Improve your online visibility" : "تحسين ظهورك على الإنترنت",
    },
    {
      icon: Shield,
      title: language === "en" ? "Security" : "الأمان",
      description: language === "en" ? "Enterprise-grade security solutions" : "حلول أمان على مستوى المؤسسات",
    },
    {
      icon: Zap,
      title: language === "en" ? "Performance" : "الأداء",
      description: language === "en" ? "Lightning-fast loading speeds" : "سرعات تحميل سريعة جداً",
    },
  ];

  return (
    <div>
      <Navbar />

      {/* Hero */}
      <section className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-gray-900 dark:to-gray-800 flex items-center pt-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <h1 className="text-5xl font-bold mb-6">
            {language === "en" ? "Our Services" : "خدماتنا"}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl">
            {language === "en"
              ? "Comprehensive web solutions for your business"
              : "حلول ويب شاملة لعملك"}
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, i) => {
              const Icon = service.icon;
              return (
                <div
                  key={i}
                  className="p-8 border border-gray-200 dark:border-gray-700 rounded-lg hover:shadow-lg dark:hover:shadow-lg dark:shadow-gray-900/50 transition group"
                >
                  <Icon className="w-12 h-12 text-primary-600 mb-4 group-hover:scale-110 transition" />
                  <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400">{service.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}