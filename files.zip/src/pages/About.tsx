import { useLanguageStore } from "@/hooks/useLanguage";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { CheckCircle } from "lucide-react";

export default function About() {
  const { language } = useLanguageStore();

  return (
    <div>
      <Navbar />

      {/* Hero */}
      <section className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-gray-900 dark:to-gray-800 flex items-center pt-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <h1 className="text-5xl font-bold mb-6">
            {language === "en" ? "About Us" : "عن الموقع"}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl">
            {language === "en"
              ? "We are a team of passionate developers and designers dedicated to creating exceptional web experiences."
              : "نحن فريق من المطورين والمصممين المتحمسين المكرسين لإنشاء تجارب ويب استثنائية."}
          </p>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">
            {language === "en" ? "Our Team" : "فريقنا"}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: language === "en" ? "Ahmed Hassan" : "أحمد حسن",
                role: language === "en" ? "CEO & Founder" : "المدير التنفيذي",
              },
              {
                name: language === "en" ? "Fatima Ali" : "فاطمة علي",
                role: language === "en" ? "Lead Designer" : "مصممة رئيسية",
              },
              {
                name: language === "en" ? "Mohamed Karim" : "محمد كريم",
                role: language === "en" ? "Tech Lead" : "قائد التكنولوجيا",
              },
            ].map((member, i) => (
              <div key={i} className="text-center">
                <div className="w-32 h-32 mx-auto mb-4 bg-gradient-to-br from-primary-400 to-secondary-400 rounded-full"></div>
                <h3 className="text-xl font-bold">{member.name}</h3>
                <p className="text-gray-600 dark:text-gray-400">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">
            {language === "en" ? "Our Values" : "قيمنا"}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: language === "en" ? "Excellence" : "التميز",
                description: language === "en" ? "We strive for excellence in everything we do" : "نسعى للتميز في كل ما نفعله",
              },
              {
                title: language === "en" ? "Innovation" : "الابتكار",
                description: language === "en" ? "We embrace innovation and new ideas" : "نتبنى الابتكار والأفكار الجديدة",
              },
              {
                title: language === "en" ? "Integrity" : "النزاهة",
                description: language === "en" ? "We operate with honesty and integrity" : "نعمل بصدق ونزاهة",
              },
            ].map((value, i) => (
              <div key={i} className="p-6 bg-white dark:bg-gray-800 rounded-lg">
                <CheckCircle size={32} className="text-primary-600 mb-4" />
                <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                <p className="text-gray-600 dark:text-gray-400">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}