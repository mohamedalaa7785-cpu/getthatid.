import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useLanguageStore } from "@/hooks/useLanguage";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Mail, Lock, LogIn } from "lucide-react";

export default function Login() {
  const { language } = useLanguageStore();
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Login logic here
    if (formData.email && formData.password) {
      setLocation("/dashboard");
    } else {
      setError(language === "en" ? "Please fill all fields" : "يرجى ملء جميع الحقول");
    }
  };

  return (
    <div>
      <Navbar />

      <section className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-gray-900 dark:to-gray-800 flex items-center pt-20">
        <div className="max-w-md mx-auto px-4 w-full">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
            <h1 className="text-3xl font-bold mb-2 text-center">
              {language === "en" ? "Welcome Back" : "مرحباً بعودتك"}
            </h1>
            <p className="text-gray-600 dark:text-gray-400 text-center mb-8">
              {language === "en" ? "Sign in to your account" : "سجل دخولك للحساب"}
            </p>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">
                  {language === "en" ? "Email" : "البريد الإلكتروني"}
                </label>
                <div className="relative">
                  <Mail size={20} className="absolute left-3 top-3 text-gray-400" />
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-600"
                    placeholder={language === "en" ? "your@email.com" : "بريدك@example.com"}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  {language === "en" ? "Password" : "كلمة المرور"}
                </label>
                <div className="relative">
                  <Lock size={20} className="absolute left-3 top-3 text-gray-400" />
                  <input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-600"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              {error && <p className="text-red-500 text-sm">{error}</p>}

              <button
                type="submit"
                className="w-full px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition flex items-center justify-center gap-2"
              >
                <LogIn size={20} />
                {language === "en" ? "Sign In" : "دخول"}
              </button>
            </form>

            <p className="text-center text-gray-600 dark:text-gray-400 mt-6">
              {language === "en" ? "Don't have an account?" : "ليس لديك حساب؟"}{" "}
              <Link href="/signup">
                <a className="text-primary-600 dark:text-primary-400 font-medium hover:underline">
                  {language === "en" ? "Sign up" : "إنشاء حساب"}
                </a>
              </Link>
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}