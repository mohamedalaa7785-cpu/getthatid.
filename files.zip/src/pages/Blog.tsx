import { useState } from "react";
import { Link } from "wouter";
import { useLanguageStore } from "@/hooks/useLanguage";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Clock, User, ArrowRight } from "lucide-react";

interface BlogPost {
  id: number;
  slug: string;
  title: string;
  excerpt: string;
  author: string;
  date: string;
  category: string;
}

const SAMPLE_POSTS: BlogPost[] = [
  {
    id: 1,
    slug: "getting-started-with-react",
    title: "Getting Started with React",
    excerpt: "Learn the basics of React and how to build your first component.",
    author: "Ahmed Hassan",
    date: "2024-01-15",
    category: "React",
  },
  {
    id: 2,
    slug: "modern-web-design-trends",
    title: "Modern Web Design Trends",
    excerpt: "Explore the latest trends in web design and UX.",
    author: "Fatima Ali",
    date: "2024-01-10",
    category: "Design",
  },
  {
    id: 3,
    slug: "typescript-best-practices",
    title: "TypeScript Best Practices",
    excerpt: "Master TypeScript and improve your code quality.",
    author: "Mohamed Karim",
    date: "2024-01-05",
    category: "TypeScript",
  },
];

export default function Blog() {
  const { language } = useLanguageStore();
  const [category, setCategory] = useState<string | null>(null);

  const filteredPosts = category
    ? SAMPLE_POSTS.filter((post) => post.category === category)
    : SAMPLE_POSTS;

  const categories = Array.from(new Set(SAMPLE_POSTS.map((p) => p.category)));

  return (
    <div>
      <Navbar />

      {/* Hero */}
      <section className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-gray-900 dark:to-gray-800 flex items-center pt-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <h1 className="text-5xl font-bold mb-6">
            {language === "en" ? "Blog" : "المدونة"}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl">
            {language === "en"
              ? "Stay updated with our latest articles and insights"
              : "ابق محدثاً مع أحدث مقالاتنا والرؤى"}
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Categories */}
          <div className="flex gap-2 mb-12 flex-wrap">
            <button
              onClick={() => setCategory(null)}
              className={`px-4 py-2 rounded-full font-medium transition ${
                category === null
                  ? "bg-primary-600 text-white"
                  : "bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600"
              }`}
            >
              {language === "en" ? "All" : "الكل"}
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-4 py-2 rounded-full font-medium transition ${
                  category === cat
                    ? "bg-primary-600 text-white"
                    : "bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Posts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post) => (
              <Link key={post.id} href={`/blog/${post.slug}`}>
                <a className="block p-6 border border-gray-200 dark:border-gray-700 rounded-lg hover:shadow-lg dark:hover:shadow-lg dark:shadow-gray-900/50 transition group">
                  {/* Image Placeholder */}
                  <div className="w-full h-40 bg-gradient-to-br from-primary-400 to-secondary-400 rounded-lg mb-4 group-hover:scale-105 transition"></div>

                  {/* Category Badge */}
                  <span className="inline-block px-3 py-1 text-xs font-medium bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-400 rounded-full mb-3">
                    {post.category}
                  </span>

                  {/* Title */}
                  <h3 className="text-xl font-bold mb-3 group-hover:text-primary-600 transition">
                    {post.title}
                  </h3>

                  {/* Excerpt */}
                  <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-2">
                    {post.excerpt}
                  </p>

                  {/* Meta */}
                  <div className="flex gap-4 text-sm text-gray-500 dark:text-gray-500 mb-4">
                    <div className="flex gap-1 items-center">
                      <User size={16} />
                      <span>{post.author}</span>
                    </div>
                    <div className="flex gap-1 items-center">
                      <Clock size={16} />
                      <span>{new Date(post.date).toLocaleDateString()}</span>
                    </div>
                  </div>

                  {/* CTA */}
                  <div className="flex items-center gap-2 text-primary-600 dark:text-primary-400 font-medium group-hover:gap-3 transition">
                    {language === "en" ? "Read More" : "اقرأ المزيد"}
                    <ArrowRight size={16} />
                  </div>
                </a>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}