import { Link } from "wouter";
import { ArrowRight, Star, CheckCircle } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useLanguageStore } from "@/hooks/useLanguage";

export default function Home() {
  const { language } = useLanguageStore();

  return (
    <div>
      <Navbar />

      {/* Hero Section */}
      <section className="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-gray-900 dark:to-gray-800 flex items-center">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            {/* Text */}
            <div className="animate-fade-in">
              <h1 className="text-5xl md:text-6xl font-bold mb-6">
                {language === "en"
                  ? "Build Your Professional Website"
                  : "بناء موقعك الاحترافي"}
              </h1>
              <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">
                {language === "en"
                  ? "Modern, fast, and secure websites built with the latest technologies."
                  : "مواقع حديثة وسريعة وآمنة مبنية بأحدث التقنيات."}
              </p>
              <div className="flex gap-4">
                <Link href="/contact">
                  <a className="px-8 py-3 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition flex items-center gap-2">
                    {language === "en" ? "Get Started" : "ابدأ الآن"}
                    <ArrowRight size={20} />
                  </a>
                </Link>
                <Link href="/about">
                  <a className="px-8 py-3 border-2 border-primary-600 text-primary-600 dark:text-primary-400 rounded-lg font-medium hover:bg-primary-50 dark:hover:bg-primary-900/20 transition">
                    {language === "en" ? "Learn More" : "اعرف أكثر"}
                  </a>
                </Link>
              </div>
            </div>

            {/* Illustration */}
            <div className="hidden md:flex justify-center">
              <div className="w-80 h-80 bg-gradient-to-br from-primary-400 to-secondary-400 rounded-2xl opacity-20 dark:opacity-10"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">
            {language === "en" ? "Why Choose Us?" : "لماذا تختارنا؟"}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: "⚡",
                title: language === "en" ? "Lightning Fast" : "سريع جداً",
                desc: language === "en" ? "Optimized for speed and performance" : "محسّن للسرعة والأداء",
              },
              {
                icon: "🔒",
                title: language === "en" ? "Secure" : "آمن",
                desc: language === "en" ? "Enterprise-grade security" : "أمان على مستوى المؤسسات",
              },
              {
                icon: "📱",
                title: language === "en" ? "Responsive" : "متجاوب",
                desc: language === "en" ? "Works on all devices" : "يعمل على جميع الأجهزة",
              },
            ].map((feature, i) => (
              <div key={i} className="p-6 border border-gray-200 dark:border-gray-700 rounded-lg hover:shadow-lg dark:hover:shadow-lg dark:shadow-gray-900/50 transition">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-400">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary-600 to-secondary-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">
            {language === "en"
              ? "Ready to Get Started?"
              : "هل أنت جاهز للبدء؟"}
          </h2>
          <p className="text-xl mb-8 opacity-90">
            {language === "en"
              ? "Contact us today and let's build something amazing together."
              : "اتصل بنا اليوم ولننشئ شيئاً رائعاً معاً."}
          </p>
          <Link href="/contact">
            <a className="px-8 py-3 bg-white text-primary-600 rounded-lg font-bold hover:bg-gray-100 transition inline-block">
              {language === "en" ? "Contact Us" : "اتصل بنا"}
            </a>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}