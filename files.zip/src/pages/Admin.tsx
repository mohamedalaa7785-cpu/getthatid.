import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  Trash2,
  Lock,
  Unlock,
  Download,
  BarChart3,
  Users,
  Phone,
  TrendingUp,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { TableSkeleton } from "@/components/SkeletonLoader";

const COLORS = ["#ef4444", "#3b82f6", "#22c55e"];

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<"stats" | "numbers" | "users">("stats");
  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const statsQuery = trpc.admin.getStats.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const numbersQuery = trpc.admin.getAllNumbers.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const usersQuery = trpc.admin.getAllUsers.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const deleteNumberMutation = trpc.admin.deleteNumber.useMutation();
  const blockUserMutation = trpc.admin.blockUser.useMutation();
  const unblockUserMutation = trpc.admin.unblockUser.useMutation();
  const exportMutation = trpc.export.exportNumbers.useMutation();
  const utils = trpc.useUtils();

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
        <Card className="bg-gray-900 border-gray-700 p-8 text-center max-w-md">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-gray-400 mb-6">You must be an admin to access this page.</p>
          <Link href="/">
            <a>
              <Button className="bg-white text-black hover:bg-gray-200 w-full">
                Back to Home
              </Button>
            </a>
          </Link>
        </Card>
      </div>
    );
  }

  const handleDeleteNumber = async (numberId: number, phoneNumber: string) => {
    if (confirm(`Delete ${phoneNumber}?`)) {
      try {
        await deleteNumberMutation.mutateAsync({ numberId });
        utils.admin.getAllNumbers.invalidate();
      } catch (error) {
        alert("Failed to delete number");
      }
    }
  };

  const handleBlockUser = async (userId: number, email: string) => {
    if (confirm(`Block user ${email}?`)) {
      try {
        await blockUserMutation.mutateAsync({ userId });
        utils.admin.getAllUsers.invalidate();
      } catch (error) {
        alert("Failed to block user");
      }
    }
  };

  const handleUnblockUser = async (userId: number, email: string) => {
    if (confirm(`Unblock user ${email}?`)) {
      try {
        await unblockUserMutation.mutateAsync({ userId });
        utils.admin.getAllUsers.invalidate();
      } catch (error) {
        alert("Failed to unblock user");
      }
    }
  };

  const handleExport = async (format: "csv" | "json") => {
    try {
      const result = await exportMutation.mutateAsync({ format });
      const element = document.createElement("a");
      element.setAttribute(
        "href",
        `data:text/${
          format === "csv" ? "csv" : "json"
        };charset=utf-8,${encodeURIComponent(result.data)}`
      );
      element.setAttribute("download", result.filename);
      element.style.display = "none";
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    } catch (error) {
      alert("Failed to export data");
    }
  };

  // Pagination helpers
  const numbersData = numbersQuery.data || [];
  const usersData = usersQuery.data || [];

  const paginatedNumbers = numbersData.slice(
    (pageNumber - 1) * pageSize,
    pageNumber * pageSize
  );
  const totalNumbersPages = Math.ceil(numbersData.length / pageSize);

  const paginatedUsers = usersData.slice(
    (pageNumber - 1) * pageSize,
    pageNumber * pageSize
  );
  const totalUsersPages = Math.ceil(usersData.length / pageSize);

  const categoryData = statsQuery.data
    ? [
        { name: "Spam", value: statsQuery.data.categoryBreakdown.spam },
        { name: "Business", value: statsQuery.data.categoryBreakdown.business },
        { name: "Personal", value: statsQuery.data.categoryBreakdown.personal },
      ]
    : [];

  const interactionData = statsQuery.data
    ? [
        { name: "Agree", value: statsQuery.data.totalAgreements },
        { name: "Disagree", value: statsQuery.data.totalDisagreements },
        { name: "Report", value: statsQuery.data.totalReports },
      ]
    : [];

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Navigation */}
      <nav className="border-b border-gray-800 py-4 sticky top-0 bg-black/95 z-40">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
          <Link href="/">
            <a className="text-2xl font-bold hover:text-gray-300 transition">GET THAT ID</a>
          </Link>
          <span className="text-gray-400">Admin Dashboard</span>
        </div>
      </nav>

      {/* Admin Panel */}
      <div className="flex-1 max-w-7xl mx-auto w-full py-8 px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <h1 className="text-4xl font-bold">Dashboard</h1>
          <div className="flex gap-2 flex-wrap">
            <Button
              onClick={() => handleExport("csv")}
              className="bg-green-600 hover:bg-green-700 flex items-center gap-2"
            >
              <Download size={16} />
              <span className="hidden sm:inline">CSV</span>
            </Button>
            <Button
              onClick={() => handleExport("json")}
              className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
            >
              <Download size={16} />
              <span className="hidden sm:inline">JSON</span>
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 md:gap-4 mb-8 border-b border-gray-800 overflow-x-auto">
          {[
            { id: "stats", label: "Statistics", icon: BarChart3 },
            { id: "numbers", label: "Numbers", icon: Phone },
            { id: "users", label: "Users", icon: Users },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setPageNumber(1);
                }}
                className={`px-4 py-2 font-medium capitalize transition flex items-center gap-2 whitespace-nowrap ${
                  activeTab === tab.id
                    ? "border-b-2 border-white text-white"
                    : "text-gray-400 hover:text-white"
                }`}
              >
                <Icon size={18} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Statistics Tab */}
        {activeTab === "stats" && (
          <div className="space-y-8 animate-in fade-in">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 md:gap-4">
              {[
                {
                  label: "Total Users",
                  value: statsQuery.data?.totalUsers || 0,
                  color: "text-blue-500",
                },
                {
                  label: "Blocked",
                  value: statsQuery.data?.blockedUsers || 0,
                  color: "text-red-500",
                },
                {
                  label: "Numbers",
                  value: statsQuery.data?.totalNumbers || 0,
                  color: "text-purple-500",
                },
                {
                  label: "Reports",
                  value: statsQuery.data?.totalReports || 0,
                  color: "text-yellow-500",
                },
                {
                  label: "Agrees",
                  value: statsQuery.data?.totalAgreements || 0,
                  color: "text-green-500",
                },
                {
                  label: "Disagrees",
                  value: statsQuery.data?.totalDisagreements || 0,
                  color: "text-red-400",
                },
              ].map((stat, i) => (
                <Card key={i} className="bg-gray-900 border-gray-700 p-4">
                  <p className="text-gray-400 text-xs md:text-sm mb-2">{stat.label}</p>
                  <p className={`text-2xl md:text-3xl font-bold ${stat.color}`}>
                    {stat.value}
                  </p>
                </Card>
              ))}
            </div>

            {/* Charts */}
            {statsQuery.data && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
                {/* Category Distribution */}
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <BarChart3 size={20} />
                    Categories
                  </h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={categoryData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="name" stroke="#9ca3af" />
                      <YAxis stroke="#9ca3af" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1f2937",
                          border: "1px solid #374151",
                          borderRadius: "8px",
                          color: "#fff",
                        }}
                      />
                      <Bar dataKey="value" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </Card>

                {/* Interactions Distribution */}
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <TrendingUp size={20} />
                    Interactions
                  </h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={interactionData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, value }) => `${name}: ${value}`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        <Cell fill="#22c55e" />
                        <Cell fill="#ef4444" />
                        <Cell fill="#eab308" />
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1f2937",
                          border: "1px solid #374151",
                          borderRadius: "8px",
                          color: "#fff",
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </Card>
              </div>
            )}
          </div>
        )}

        {/* Numbers Tab */}
        {activeTab === "numbers" && (
          <div className="animate-in fade-in">
            {numbersQuery.isLoading ? (
              <TableSkeleton rows={5} />
            ) : paginatedNumbers.length > 0 ? (
              <>
                <div className="overflow-x-auto rounded-lg border border-gray-700">
                  <table className="w-full text-sm md:text-base">
                    <thead className="bg-gray-800 border-b border-gray-700">
                      <tr>
                        <th className="text-left py-3 px-2 md:px-4 font-semibold">Phone</th>
                        <th className="text-left py-3 px-2 md:px-4 font-semibold hidden sm:table-cell">Name</th>
                        <th className="text-left py-3 px-2 md:px-4 font-semibold hidden md:table-cell">Category</th>
                        <th className="text-center py-3 px-2 md:px-4 font-semibold">Agree</th>
                        <th className="text-center py-3 px-2 md:px-4 font-semibold hidden sm:table-cell">Disagree</th>
                        <th className="text-center py-3 px-2 md:px-4 font-semibold hidden md:table-cell">Reports</th>
                        <th className="text-center py-3 px-2 md:px-4 font-semibold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedNumbers.map((number: any, idx) => (
                        <tr
                          key={number.id}
                          className={`border-b border-gray-800 hover:bg-gray-800/50 transition ${
                            idx % 2 === 0 ? "bg-gray-900/50" : ""
                          }`}
                        >
                          <td className="py-3 px-2 md:px-4 font-mono text-xs md:text-sm">
                            {number.phoneNumber}
                          </td>
                          <td className="py-3 px-2 md:px-4 truncate max-w-xs hidden sm:table-cell text-sm">
                            {number.name}
                          </td>
                          <td className="py-3 px-2 md:px-4 hidden md:table-cell">
                            <span
                              className={`px-2 py-1 rounded text-xs font-medium ${
                                number.category === "spam"
                                  ? "bg-red-900 text-red-200"
                                  : number.category === "business"
                                  ? "bg-blue-900 text-blue-200"
                                  : "bg-green-900 text-green-200"
                              }`}
                            >
                              {number.category}
                            </span>
                          </td>
                          <td className="py-3 px-2 md:px-4 text-center text-green-500 font-semibold text-sm">
                            {number.agreeCount}
                          </td>
                          <td className="py-3 px-2 md:px-4 text-center text-red-500 font-semibold hidden sm:table-cell text-sm">
                            {number.disagreeCount}
                          </td>
                          <td className="py-3 px-2 md:px-4 text-center text-yellow-500 font-semibold hidden md:table-cell text-sm">
                            {number.reportCount}
                          </td>
                          <td className="py-3 px-2 md:px-4 text-center">
                            <Button
                              size="sm"
                              onClick={() =>
                                handleDeleteNumber(number.id, number.phoneNumber)
                              }
                              disabled={deleteNumberMutation.isPending}
                              className="bg-red-600 hover:bg-red-700 text-white"
                            >
                              <Trash2 size={14} />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                <div className="mt-6 flex flex-wrap justify-center items-center gap-2">
                  <Button
                    onClick={() => setPageNumber(Math.max(1, pageNumber - 1))}
                    disabled={pageNumber === 1}
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                  >
                    <ChevronLeft size={16} />
                    <span className="hidden sm:inline">Previous</span>
                  </Button>
                  <div className="flex items-center gap-1 text-sm">
                    <span className="text-gray-400">
                      Page
                      <span className="font-semibold text-white mx-1">{pageNumber}</span>
                      of
                      <span className="font-semibold text-white ml-1">{totalNumbersPages}</span>
                    </span>
                  </div>
                  <Button
                    onClick={() =>
                      setPageNumber(Math.min(totalNumbersPages, pageNumber + 1))
                    }
                    disabled={pageNumber === totalNumbersPages}
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                  >
                    <span className="hidden sm:inline">Next</span>
                    <ChevronRight size={16} />
                  </Button>
                </div>
              </>
            ) : (
              <Card className="bg-gray-900 border-gray-700 p-8 text-center">
                <Phone size={32} className="mx-auto mb-4 text-gray-500" />
                <p className="text-gray-400">No phone numbers found</p>
              </Card>
            )}
          </div>
        )}

        {/* Users Tab */}
        {activeTab === "users" && (
          <div className="animate-in fade-in">
            {usersQuery.isLoading ? (
              <TableSkeleton rows={5} />
            ) : paginatedUsers.length > 0 ? (
              <>
                <div className="overflow-x-auto rounded-lg border border-gray-700">
                  <table className="w-full text-sm md:text-base">
                    <thead className="bg-gray-800 border-b border-gray-700">
                      <tr>
                        <th className="text-left py-3 px-2 md:px-4 font-semibold">Email</th>
                        <th className="text-left py-3 px-2 md:px-4 font-semibold hidden sm:table-cell">Name</th>
                        <th className="text-left py-3 px-2 md:px-4 font-semibold hidden md:table-cell">Role</th>
                        <th className="text-center py-3 px-2 md:px-4 font-semibold">Status</th>
                        <th className="text-left py-3 px-2 md:px-4 font-semibold hidden lg:table-cell">Joined</th>
                        <th className="text-center py-3 px-2 md:px-4 font-semibold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedUsers.map((u: any, idx) => (
                        <tr
                          key={u.id}
                          className={`border-b border-gray-800 hover:bg-gray-800/50 transition ${
                            idx % 2 === 0 ? "bg-gray-900/50" : ""
                          }`}
                        >
                          <td className="py-3 px-2 md:px-4 font-mono text-xs md:text-sm truncate">
                            {u.email}
                          </td>
                          <td className="py-3 px-2 md:px-4 truncate hidden sm:table-cell text-sm">
                            {u.name || "-"}
                          </td>
                          <td className="py-3 px-2 md:px-4 hidden md:table-cell">
                            <span
                              className={`px-2 py-1 rounded text-xs font-medium ${
                                u.role === "admin"
                                  ? "bg-purple-900 text-purple-200"
                                  : "bg-gray-700 text-gray-200"
                              }`}
                            >
                              {u.role}
                            </span>
                          </td>
                          <td className="py-3 px-2 md:px-4 text-center">
                            <span
                              className={`font-medium text-xs md:text-sm ${
                                u.isBlocked ? "text-red-500" : "text-green-500"
                              }`}
                            >
                              {u.isBlocked ? "Blocked" : "Active"}
                            </span>
                          </td>
                          <td className="py-3 px-2 md:px-4 text-sm text-gray-400 hidden lg:table-cell">
                            {new Date(u.createdAt).toLocaleDateString()}
                          </td>
                          <td className="py-3 px-2 md:px-4 text-center">
                            {u.isBlocked ? (
                              <Button
                                size="sm"
                                onClick={() => handleUnblockUser(u.id, u.email)}
                                disabled={unblockUserMutation.isPending}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <Unlock size={14} />
                              </Button>
                            ) : (
                              <Button
                                size="sm"
                                onClick={() => handleBlockUser(u.id, u.email)}
                                disabled={blockUserMutation.isPending}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                <Lock size={14} />
                              </Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                <div className="mt-6 flex flex-wrap justify-center items-center gap-2">
                  <Button
                    onClick={() => setPageNumber(Math.max(1, pageNumber - 1))}
                    disabled={pageNumber === 1}
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                  >
                    <ChevronLeft size={16} />
                    <span className="hidden sm:inline">Previous</span>
                  </Button>
                  <div className="flex items-center gap-1 text-sm">
                    <span className="text-gray-400">
                      Page
                      <span className="font-semibold text-white mx-1">{pageNumber}</span>
                      of
                      <span className="font-semibold text-white ml-1">{totalUsersPages}</span>
                    </span>
                  </div>
                  <Button
                    onClick={() =>
                      setPageNumber(Math.min(totalUsersPages, pageNumber + 1))
                    }
                    disabled={pageNumber === totalUsersPages}
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                  >
                    <span className="hidden sm:inline">Next</span>
                    <ChevronRight size={16} />
                  </Button>
                </div>
              </>
            ) : (
              <Card className="bg-gray-900 border-gray-700 p-8 text-center">
                <Users size={32} className="mx-auto mb-4 text-gray-500" />
                <p className="text-gray-400">No users found</p>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}