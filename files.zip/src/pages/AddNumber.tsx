import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { useFormValidation } from "@/hooks/useFormValidation";
import { formatPhoneNumber, sanitizeString } from "@/utils/sanitize";
import {
  CheckCircle,
  AlertCircle,
  Phone,
  FileText,
  Loader,
} from "lucide-react";

export default function AddNumber() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const { errors, validate, setError, clearErrors } = useFormValidation();

  const [phoneNumber, setPhoneNumber] = useState("");
  const [name, setName] = useState("");
  const [category, setCategory] = useState<"spam" | "business" | "personal">(
    "personal"
  );
  const [success, setSuccess] = useState("");

  const addNumberMutation = trpc.numbers.add.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
        <Card className="bg-gray-900 border-gray-700 p-8 text-center max-w-md">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-gray-400 mb-6">You must be logged in to add a number.</p>
          <Link href="/login">
            <a>
              <Button className="bg-white text-black hover:bg-gray-200 w-full">
                Login
              </Button>
            </a>
          </Link>