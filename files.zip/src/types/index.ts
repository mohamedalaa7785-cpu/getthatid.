/**
 * Global Type Definitions
 */

export type UserRole = "user" | "admin";
export type PhoneCategory = "spam" | "business" | "personal";
export type InteractionAction = "agree" | "disagree" | "report";
export type ToastType = "success" | "error" | "info" | "warning";

/**
 * User Types
 */
export interface User {
  id: number;
  email: string;
  name: string | null;
  phone: string | null;
  role: UserRole;
  isBlocked: number;
  emailVerified: number;
  reputationScore: number;
  accuracyRating: number;
  notificationsEnabled: number;
  createdAt: Date;
  updatedAt: Date;
  lastSignedIn: Date;
}

/**
 * Phone Number Types
 */
export interface PhoneNumber {
  id: number;
  phoneNumber: string;
  name: string;
  category: PhoneCategory;
  agreeCount: number;
  disagreeCount: number;
  reportCount: number;
  createdBy: number;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Interaction Types
 */
export interface Interaction {
  id: number;
  userId: number;
  numberId: number;
  action: InteractionAction;
  createdAt: Date;
}

/**
 * Search Results Types
 */
export interface SearchResult {
  found: boolean;
  data: PhoneNumber | null;
}

export interface AdvancedSearchResult {
  results: PhoneNumber[];
  total: number;
  limit: number;
  offset: number;
  hasMore: boolean;
  pages: number;
}

/**
 * Statistics Types
 */
export interface DashboardStats {
  totalUsers: number;
  totalNumbers: number;
  blockedUsers: number;
  totalReports: number;
  totalAgreements: number;
  totalDisagreements: number;
  categoryBreakdown: {
    spam: number;
    business: number;
    personal: number;
  };
}

/**
 * Reputation Types
 */
export interface UserReputation {
  reputationScore: number;
  accuracyRating: number;
}

export interface Badge {
  badge: "expert" | "trusted" | "contributor" | "active" | "new";
  color: string;
}

/**
 * Notification Types
 */
export interface Notification {
  id: number;
  userId: number;
  title: string;
  content: string;
  type: ToastType;
  read: number;
  createdAt: Date;
}

/**
 * Form Types
 */
export interface FormError {
  [key: string]: string;
}

/**
 * API Response Types
 */
export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, any>;
}