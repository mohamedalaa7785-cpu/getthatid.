/**
 * API Service Layer
 * Centralized API calls management
 */

import { ENV } from "@/config/env";
import { logApiActivity, formatApiError } from "@/lib/api-helpers";

export interface RequestConfig {
  headers?: Record<string, string>;
  timeout?: number;
  retries?: number;
}

class ApiService {
  private baseUrl: string;
  private timeout: number;

  constructor(baseUrl: string = ENV.API_URL, timeout: number = ENV.API_TIMEOUT) {
    this.baseUrl = baseUrl;
    this.timeout = timeout;
  }

  /**
   * Fetch wrapper with error handling
   */
  private async fetchWithTimeout(
    url: string,
    options: RequestInit & { timeout?: number } = {}
  ): Promise<Response> {
    const timeout = options.timeout || this.timeout;
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);

    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
      });
      clearTimeout(id);
      return response;
    } catch (error) {
      clearTimeout(id);
      throw error;
    }
  }

  /**
   * GET request
   */
  async get<T>(endpoint: string, config?: RequestConfig): Promise<T> {
    try {
      logApiActivity("GET", { endpoint });

      const response = await this.fetchWithTimeout(
        `${this.baseUrl}${endpoint}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            ...config?.headers,
          },
          timeout: config?.timeout,
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      logApiActivity("GET Success", { endpoint, data });
      return data as T;
    } catch (error) {
      const formatted = formatApiError(error);
      logApiActivity("GET Error", { endpoint, error: formatted }, "error");
      throw error;
    }
  }

  /**
   * POST request
   */
  async post<T>(
    endpoint: string,
    body?: Record<string, any>,
    config?: RequestConfig
  ): Promise<T> {
    try {
      logApiActivity("POST", { endpoint, body });

      const response = await this.fetchWithTimeout(
        `${this.baseUrl}${endpoint}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...config?.headers,
          },
          body: body ? JSON.stringify(body) : undefined,
          timeout: config?.timeout,
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      logApiActivity("POST Success", { endpoint, data });
      return data as T;
    } catch (error) {
      const formatted = formatApiError(error);
      logApiActivity("POST Error", { endpoint, error: formatted }, "error");
      throw error;
    }
  }

  /**
   * PUT request
   */
  async put<T>(
    endpoint: string,
    body?: Record<string, any>,
    config?: RequestConfig
  ): Promise<T> {
    try {
      logApiActivity("PUT", { endpoint, body });

      const response = await this.fetchWithTimeout(
        `${this.baseUrl}${endpoint}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            ...config?.headers,
          },
          body: body ? JSON.stringify(body) : undefined,
          timeout: config?.timeout,
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      logApiActivity("PUT Success", { endpoint, data });
      return data as T;
    } catch (error) {
      const formatted = formatApiError(error);
      logApiActivity("PUT Error", { endpoint, error: formatted }, "error");
      throw error;
    }
  }

  /**
   * DELETE request
   */
  async delete<T>(endpoint: string, config?: RequestConfig): Promise<T> {
    try {
      logApiActivity("DELETE", { endpoint });

      const response = await this.fetchWithTimeout(
        `${this.baseUrl}${endpoint}`,
        {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
            ...config?.headers,
          },
          timeout: config?.timeout,
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      logApiActivity("DELETE Success", { endpoint, data });
      return data as T;
    } catch (error) {
      const formatted = formatApiError(error);
      logApiActivity("DELETE Error", { endpoint, error: formatted }, "error");
      throw error;
    }
  }

  /**
   * Check if API is healthy
   */
  async healthCheck(): Promise<boolean> {
    try {
      const response = await this.fetchWithTimeout(`${this.baseUrl}/health`, {
        method: "GET",
        timeout: 5000,
      });
      return response.ok;
    } catch {
      return false;
    }
  }
}

// Export singleton instance
export const apiService = new ApiService();

export default apiService;