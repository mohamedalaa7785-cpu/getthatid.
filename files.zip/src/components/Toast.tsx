import { AlertCircle, CheckCircle, Info, AlertTriangle, X } from "lucide-react";
import { useEffect, useState } from "react";

export type ToastType = "success" | "error" | "info" | "warning";

export interface ToastProps {
  message: string;
  type?: ToastType;
  duration?: number;
  onClose?: () => void;
}

const iconMap = {
  success: <CheckCircle className="text-green-500" size={20} />,
  error: <AlertCircle className="text-red-500" size={20} />,
  info: <Info className="text-blue-500" size={20} />,
  warning: <AlertTriangle className="text-yellow-500" size={20} />,
};

const colorMap = {
  success: "bg-green-900/20 border-green-700 text-green-200",
  error: "bg-red-900/20 border-red-700 text-red-200",
  info: "bg-blue-900/20 border-blue-700 text-blue-200",
  warning: "bg-yellow-900/20 border-yellow-700 text-yellow-200",
};

export function Toast({
  message,
  type = "info",
  duration = 5000,
  onClose,
}: ToastProps) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    if (duration && duration > 0) {
      const timer = setTimeout(() => {
        setIsVisible(false);
        onClose?.();
      }, duration);

      return () => clearTimeout(timer);
    }
  }, [duration, onClose]);

  if (!isVisible) return null;

  return (
    <div className={`fixed bottom-4 right-4 p-4 rounded-lg border flex items-center gap-3 z-50 animate-in fade-in slide-in-from-bottom-4 ${colorMap[type]}`}>
      {iconMap[type]}
      <p className="flex-1">{message}</p>
      <button
        onClick={() => {
          setIsVisible(false);
          onClose?.();
        }}
        className="hover:opacity-75 transition"
      >
        <X size={18} />
      </button>
    </div>
  );
}

// Toast container for multiple toasts
export function ToastContainer() {
  const [toasts, setToasts] = useState<(ToastProps & { id: string })[]>([]);

  const addToast = (toast: ToastProps) => {
    const id = Date.now().toString();
    const newToast = { ...toast, id };
    setToasts((prev) => [...prev, newToast]);

    return () => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    };
  };

  return (
    <>
      <div className="fixed bottom-4 right-4 space-y-3 z-50">
        {toasts.map((toast) => (
          <Toast
            key={toast.id}
            {...toast}
            onClose={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
          />
        ))}
      </div>
    </>
  );
}

// Hook for using toast
export function useToast() {
  return {
    success: (message: string) => ({ message, type: "success" as const }),
    error: (message: string) => ({ message, type: "error" as const }),
    info: (message: string) => ({ message, type: "info" as const }),
    warning: (message: string) => ({ message, type: "warning" as const }),
  };
}