import { Component, ReactNode } from "react";
import { AlertTriangle, Home } from "lucide-react";
import { Link } from "wouter";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 max-w-md text-center">
            <AlertTriangle size={48} className="mx-auto mb-4 text-red-600" />
            <h1 className="text-2xl font-bold mb-4">
              Something went wrong!
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {this.state.error?.message}
            </p>
            <Link href="/">
              <a className="px-6 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition inline-flex items-center gap-2">
                <Home size={20} />
                Go Home
              </a>
            </Link>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}