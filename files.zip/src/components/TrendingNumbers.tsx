import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { TrendingUp, AlertTriangle, Heart, Loader } from "lucide-react";
import { CardSkeleton } from "@/components/SkeletonLoader";

interface TrendingNumber {
  id: number;
  phoneNumber: string;
  name: string;
  category: "spam" | "business" | "personal";
  agreeCount: number;
  reportCount: number;
}

export default function TrendingNumbers({
  onSelect,
}: {
  onSelect: (number: TrendingNumber) => void;
}) {
  const { data: trending, isLoading } = trpc.numbers.getTrending.useQuery({
    limit: 5,
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <CardSkeleton />
        <CardSkeleton />
        <CardSkeleton />
      </div>
    );
  }

  if (!trending || trending.length === 0) {
    return null;
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "spam":
        return "bg-red-900 text-red-200";
      case "business":
        return "bg-blue-900 text-blue-200";
      default:
        return "bg-green-900 text-green-200";
    }
  };

  return (
    <Card className="bg-gray-900 border-gray-700 p-6">
      <div className="flex items-center gap-2 mb-6">
        <TrendingUp size={24} className="text-yellow-500" />
        <div>
          <h3 className="text-xl font-bold">Trending This Week</h3>
          <p className="text-sm text-gray-400">Most discussed numbers</p>
        </div>
      </div>

      <div className="space-y-3">
        {trending.map((number: any, index) => (
          <button
            key={number.id}
            onClick={() => onSelect(number)}
            className="w-full text-left p-4 bg-gray-800 hover:bg-gray-700 rounded-lg transition border border-gray-700 hover:border-gray-600 group"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="font-bold text-yellow-500 text-lg">#{index + 1}</span>
                  <p className="font-semibold group-hover:text-white transition truncate">
                    {number.name}
                  </p>
                  <span className={`text-xs px-2 py-0.5 rounded ${getCategoryColor(number.category)}`}>
                    {number.category}
                  </span>
                </div>
                <p className="text-sm text-gray-400 font-mono">{number.phoneNumber}</p>
              </div>
              <div className="text-right text-sm flex-shrink-0">
                <div className="flex items-center gap-1 text-green-500 font-semibold mb-1">
                  <Heart size={14} />
                  {number.agreeCount}
                </div>
                {number.reportCount > 0 && (
                  <div className="flex items-center gap-1 text-red-500 justify-end">
                    <AlertTriangle size={14} />
                    {number.reportCount}
                  </div>
                )}
              </div>
            </div>
          </button>
        ))}
      </div>
    </Card>
  );
}