import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Phone, History, Loader, X } from "lucide-react";
import { useSearchHistory } from "@/hooks/useSearchHistory";
import { useDebounce } from "@/hooks/useDebounce";
import { formatPhoneNumber } from "@/utils/sanitize";

interface Suggestion {
  id: number;
  phoneNumber: string;
  name: string;
  category: "spam" | "business" | "personal";
  agreeCount: number;
}

export default function SearchSuggestions({
  onSelect,
}: {
  onSelect: (phoneNumber: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const { history, addSearch } = useSearchHistory();
  const debouncedQuery = useDebounce(query, 300);
  const searchMutation = trpc.numbers.advancedSearch.useMutation();

  // Perform search on debounced query change
  useEffect(() => {
    if (debouncedQuery.length < 2) {
      setSuggestions([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    searchMutation
      .mutateAsync({
        query: debouncedQuery,
        limit: 5,
      })
      .then((result) => {
        setSuggestions(result.results as Suggestion[]);
      })
      .catch((error) => {
        console.error("Search error:", error);
        setSuggestions([]);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [debouncedQuery, searchMutation]);

  const handleSelectSuggestion = (phoneNumber: string) => {
    const formatted = formatPhoneNumber(phoneNumber);
    addSearch(formatted);
    onSelect(formatted);
    setQuery("");
    setSuggestions([]);
    setIsOpen(false);
  };

  const handleClear = () => {
    setQuery("");
    setIsOpen(false);
  };

  return (
    <div className="relative w-full">
      <div className="relative">
        <Input
          type="tel"
          placeholder="Search phone numbers..."
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          className="bg-gray-900 border-gray-700 text-white placeholder-gray-500 pr-10"
        />
        {query && (
          <button
            onClick={handleClear}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition"
          >
            <X size={18} />
          </button>
        )}
      </div>

      {isOpen && (
        <>
          {/* Overlay */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />

          {/* Dropdown */}
          <Card className="absolute top-12 left-0 right-0 bg-gray-900 border-gray-700 max-h-96 overflow-y-auto z-50 shadow-xl">
            {/* Loading State */}
            {isLoading && query.length >= 2 && (
              <div className="px-4 py-6 flex justify-center">
                <Loader size={20} className="animate-spin text-gray-400" />
              </div>
            )}

            {/* Search Results */}
            {!isLoading && query.length >= 2 && suggestions.length > 0 && (
              <div>
                <div className="px-4 py-2 text-xs font-semibold text-gray-400 border-b border-gray-700 bg-gray-800 sticky top-0">
                  SEARCH RESULTS ({suggestions.length})
                </div>
                {suggestions.map((suggestion) => (
                  <button
                    key={suggestion.id}
                    onClick={() => handleSelectSuggestion(suggestion.phoneNumber)}
                    className="w-full text-left px-4 py-3 hover:bg-gray-800 border-b border-gray-800 last:border-b-0 transition"
                  >
                    <div className="flex items-center gap-3">
                      <Phone size={16} className="text-gray-500 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{suggestion.name}</p>
                        <p className="text-sm text-gray-400 font-mono">
                          {suggestion.phoneNumber}
                        </p>
                      </div>
                      <span
                        className={`text-xs px-2 py-1 rounded flex-shrink-0 ${
                          suggestion.category === "spam"
                            ? "bg-red-900 text-red-200"
                            : suggestion.category === "business"
                            ? "bg-blue-900 text-blue-200"
                            : "bg-green-900 text-green-200"
                        }`}
                      >
                        {suggestion.category}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* Recent Searches */}
            {!query && history.length > 0 && (
              <div>
                <div className="px-4 py-2 text-xs font-semibold text-gray-400 border-b border-gray-700 bg-gray-800 sticky top-0">
                  RECENT SEARCHES
                </div>
                {history.map((search, index) => (
                  <button
                    key={index}
                    onClick={() => handleSelectSuggestion(search)}
                    className="w-full text-left px-4 py-3 hover:bg-gray-800 border-b border-gray-800 last:border-b-0 flex items-center gap-2 transition"
                  >
                    <History size={16} className="text-gray-500" />
                    <span>{search}</span>
                  </button>
                ))}
              </div>
            )}

            {/* No Results */}
            {!isLoading && query.length >= 2 && suggestions.length === 0 && (
              <div className="px-4 py-6 text-center text-gray-400">
                <Phone size={24} className="mx-auto mb-2 opacity-50" />
                <p>No results found for "{query}"</p>
              </div>
            )}

            {/* Empty State */}
            {!query && history.length === 0 && (
              <div className="px-4 py-6 text-center text-gray-500 text-sm">
                <p>🔍 Start typing to search...</p>
              </div>
            )}
          </Card>
        </>
      )}
    </div>
  );
}