import { Link } from "wouter";
import { Facebook, Twitter, LinkedIn, Mail, Phone, MapPin } from "lucide-react";
import { useLanguageStore } from "@/hooks/useLanguage";

export default function Footer() {
  const { language } = useLanguageStore();
  const currentYear = new Date().getFullYear();

  const footerLinks = language === "en" ? {
    company: { title: "Company", links: ["About", "Services", "Team", "Careers"] },
    resources: { title: "Resources", links: ["Blog", "Documentation", "FAQ", "Support"] },
    legal: { title: "Legal", links: ["Privacy Policy", "Terms of Service", "Contact"] },
  } : {
    company: { title: "الشركة", links: ["عن الموقع", "الخدمات", "الفريق", "الوظائف"] },
    resources: { title: "الموارد", links: ["المدونة", "التوثيق", "الأسئلة الشائعة", "الدعم"] },
    legal: { title: "القانوني", links: ["سياسة الخصوصية", "شروط الخدمة", "اتصل بنا"] },
  };

  return (
    <footer className="bg-gray-900 text-gray-300 mt-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* About */}
          <div>
            <h3 className="text-xl font-bold text-white mb-4">ProWeb</h3>
            <p className="text-sm text-gray-400 mb-4">
              {language === "en"
                ? "Building professional websites for modern businesses."
                : "بناء مواقع احترافية للشركات الحديثة."}
            </p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-primary-400 transition">
                <Facebook size={20} />
              </a>
              <a href="#" className="hover:text-primary-400 transition">
                <Twitter size={20} />
              </a>
              <a href="#" className="hover:text-primary-400 transition">
                <LinkedIn size={20} />
              </a>
            </div>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-bold text-white mb-4">{footerLinks.company.title}</h4>
            <ul className="space-y-2">
              {footerLinks.company.links.map((link) => (
                <li key={link}>
                  <a href="#" className="text-sm hover:text-primary-400 transition">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-bold text-white mb-4">{footerLinks.resources.title}</h4>
            <ul className="space-y-2">
              {footerLinks.resources.links.map((link) => (
                <li key={link}>
                  <a href="#" className="text-sm hover:text-primary-400 transition">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-white mb-4">
              {language === "en" ? "Contact" : "اتصل بنا"}
            </h4>
            <ul className="space-y-3">
              <li className="flex gap-2">
                <Mail size={16} className="text-primary-400 flex-shrink-0 mt-1" />
                <a href="mailto:info@example.com" className="text-sm hover:text-primary-400 transition">
                  info@example.com
                </a>
              </li>
              <li className="flex gap-2">
                <Phone size={16} className="text-primary-400 flex-shrink-0 mt-1" />
                <a href="tel:+201234567890" className="text-sm hover:text-primary-400 transition">
                  +20 123 456 7890
                </a>
              </li>
              <li className="flex gap-2">
                <MapPin size={16} className="text-primary-400 flex-shrink-0 mt-1" />
                <span className="text-sm">Cairo, Egypt</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-gray-400">
              © {currentYear} ProWeb. {language === "en" ? "All rights reserved." : "جميع الحقوق محفوظة."}
            </p>
            <div className="flex gap-6">
              <Link href="/privacy">
                <a className="text-sm text-gray-400 hover:text-primary-400 transition">
                  {language === "en" ? "Privacy Policy" : "سياسة الخصوصية"}
                </a>
              </Link>
              <Link href="/terms">
                <a className="text-sm text-gray-400 hover:text-primary-400 transition">
                  {language === "en" ? "Terms of Service" : "شروط الخدمة"}
                </a>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}