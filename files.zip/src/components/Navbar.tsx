import { useState } from "react";
import { Link } from "wouter";
import { Menu, X, Moon, Sun } from "lucide-react";
import { useThemeStore } from "@/hooks/useTheme";
import { useLanguageStore } from "@/hooks/useLanguage";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { isDark, toggleTheme } = useThemeStore();
  const { language, toggleLanguage } = useLanguageStore();

  const navLinks = [
    { href: "/", label: language === "en" ? "Home" : "الرئيسية" },
    { href: "/about", label: language === "en" ? "About" : "عن الموقع" },
    { href: "/services", label: language === "en" ? "Services" : "الخدمات" },
    { href: "/blog", label: language === "en" ? "Blog" : "المدونة" },
    { href: "/contact", label: language === "en" ? "Contact" : "اتصل بنا" },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/">
            <a className="text-2xl font-bold bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
              ProWeb
            </a>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex gap-8 items-center">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <a className="text-gray-700 dark:text-gray-300 hover:text-primary-600 dark:hover:text-primary-400 transition">
                  {link.label}
                </a>
              </Link>
            ))}
          </div>

          {/* Right Side Controls */}
          <div className="flex gap-4 items-center">
            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition"
            >
              {isDark ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            {/* Language Toggle */}
            <button
              onClick={toggleLanguage}
              className="px-3 py-2 bg-gray-100 dark:bg-gray-800 rounded-lg text-sm font-medium hover:bg-gray-200 dark:hover:bg-gray-700 transition"
            >
              {language === "en" ? "العربية" : "English"}
            </button>

            {/* Auth Links */}
            <Link href="/login">
              <a className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-primary-600">
                {language === "en" ? "Login" : "دخول"}
              </a>
            </Link>

            <Link href="/signup">
              <a className="px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700 transition">
                {language === "en" ? "Sign Up" : "تسجيل"}
              </a>
            </Link>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden pb-4 space-y-2">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <a
                  onClick={() => setMobileMenuOpen(false)}
                  className="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
                >
                  {link.label}
                </a>
              </Link>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}