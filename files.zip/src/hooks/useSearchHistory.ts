import { useEffect, useState } from "react";

const STORAGE_KEY = "searchHistory";

export function useSearchHistory() {
  const [history, setHistory] = useState<string[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load history from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        setHistory(JSON.parse(saved));
      }
    } catch (e) {
      console.error("Failed to load search history:", e);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  const addSearch = (phoneNumber: string) => {
    if (!phoneNumber.trim()) return;

    setHistory((prev) => {
      const updated = [
        phoneNumber,
        ...prev.filter((h) => h !== phoneNumber),
      ].slice(0, 10);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem(STORAGE_KEY);
  };

  const removeSearch = (phoneNumber: string) => {
    setHistory((prev) => {
      const updated = prev.filter((h) => h !== phoneNumber);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  return { history, addSearch, clearHistory, removeSearch, isLoaded };
}