/**
 * Application Logger
 */

import { ENV } from "@/config/env";

type LogLevel = "info" | "warn" | "error" | "debug";

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  data?: any;
  stack?: string;
}

class Logger {
  private logs: LogEntry[] = [];
  private maxLogs = 1000;

  /**
   * Log message with level
   */
  private log(level: LogLevel, message: string, data?: any) {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      data,
    };

    // Add to memory
    this.logs.push(entry);
    if (this.logs.length > this.maxLogs) {
      this.logs.shift();
    }

    // Log to console in development
    if (ENV.DEBUG) {
      const style = this.getConsoleStyle(level);
      console.log(
        `%c[${level.toUpperCase()}]%c ${message}`,
        style,
        "color: inherit"
      );
      if (data) {
        console.log(data);
      }
    }

    // Send to analytics in production
    if (!ENV.DEBUG && level === "error") {
      this.sendToAnalytics(entry);
    }
  }

  /**
   * Get console style for level
   */
  private getConsoleStyle(level: LogLevel): string {
    const styles = {
      info: "color: #0066cc; font-weight: bold",
      warn: "color: #ff9900; font-weight: bold",
      error: "color: #cc0000; font-weight: bold",
      debug: "color: #666666; font-weight: bold",
    };
    return styles[level];
  }

  /**
   * Send error to analytics (implement as needed)
   */
  private sendToAnalytics(entry: LogEntry) {
    // This could be integrated with Sentry, LogRocket, etc.
    if (ENV.DEBUG) {
      console.log("Would send to analytics:", entry);
    }
  }

  /**
   * Public methods
   */
  info(message: string, data?: any) {
    this.log("info", message, data);
  }

  warn(message: string, data?: any) {
    this.log("warn", message, data);
  }

  error(message: string, data?: any) {
    this.log("error", message, data);
  }

  debug(message: string, data?: any) {
    this.log("debug", message, data);
  }

  /**
   * Get all logs
   */
  getLogs(): LogEntry[] {
    return [...this.logs];
  }

  /**
   * Clear logs
   */
  clearLogs() {
    this.logs = [];
  }

  /**
   * Export logs as JSON
   */
  exportLogs(): string {
    return JSON.stringify(this.logs, null, 2);
  }
}

// Export singleton
export const logger = new Logger();

export default logger;