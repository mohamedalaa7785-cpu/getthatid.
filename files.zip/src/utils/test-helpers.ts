/**
 * Testing Helper Functions
 */

/**
 * Mock phone numbers for testing
 */
export const MOCK_PHONE_NUMBERS = [
  "(555) 123-4567",
  "(555) 234-5678",
  "(555) 345-6789",
  "(555) 456-7890",
  "(555) 567-8901",
];

/**
 * Mock users for testing
 */
export const MOCK_USERS = [
  {
    id: 1,
    email: "test@example.com",
    name: "Test User",
    phone: "(555) 123-4567",
    role: "user" as const,
    reputationScore: 100,
  },
  {
    id: 2,
    email: "admin@example.com",
    name: "Admin User",
    phone: "(555) 234-5678",
    role: "admin" as const,
    reputationScore: 500,
  },
];

/**
 * Mock phone numbers data
 */
export const MOCK_NUMBERS = [
  {
    id: 1,
    phoneNumber: "(555) 123-4567",
    name: "Pizza Place",
    category: "business" as const,
    agreeCount: 10,
    disagreeCount: 1,
    reportCount: 0,
  },
  {
    id: 2,
    phoneNumber: "(555) 234-5678",
    name: "Spam Caller",
    category: "spam" as const,
    agreeCount: 2,
    disagreeCount: 15,
    reportCount: 20,
  },
];

/**
 * Create mock API response
 */
export function createMockResponse<T>(data: T, ok = true) {
  return {
    ok,
    json: async () => data,
    status: ok ? 200 : 400,
    statusText: ok ? "OK" : "Bad Request",
  } as Response;
}

/**
 * Delay for async operations
 */
export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Create mock tRPC context
 */
export function createMockContext() {
  return {
    user: MOCK_USERS[0],
    req: {
      ip: "127.0.0.1",
      protocol: "https",
      headers: {},
    },
    res: {},
  };
}

/**
 * Mock localStorage
 */
export const createMockStorage = () => {
  let store: Record<string, string> = {};

  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value.toString();
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    },
  };
};