/**
 * Input Validation & Sanitization Utilities
 * المسؤول عن التحقق من صحة البيانات المدخلة وتنظيفها
 */

export function sanitizeString(input: string, maxLength: number = 500): string {
  if (!input) return "";
  return input
    .trim()
    .slice(0, maxLength)
    .replace(/[<>]/g, ""); // Remove potential HTML tags
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 320;
}

export function validatePhoneNumber(phone: string): boolean {
  const cleaned = phone.replace(/\D/g, "");
  return (
    (cleaned.length === 10 || (cleaned.length === 11 && cleaned.startsWith("1"))) &&
    phone.length <= 20
  );
}

export function validatePassword(password: string): boolean {
  return password.length >= 6 && password.length <= 128;
}

export function formatPhoneNumber(phone: string): string {
  const cleaned = phone.replace(/\D/g, "");

  if (cleaned.length === 10) {
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  } else if (cleaned.length === 11 && cleaned.startsWith("1")) {
    return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
  }

  return phone;
}

export interface ValidationResult {
  valid: boolean;
  error?: string;
}

export function validateInput(
  input: string,
  type: "email" | "phone" | "text" | "password"
): ValidationResult {
  const trimmed = input.trim();

  switch (type) {
    case "email":
      if (!trimmed) return { valid: false, error: "Email is required" };
      if (!validateEmail(trimmed)) {
        return { valid: false, error: "Invalid email format" };
      }
      return { valid: true };

    case "phone":
      if (!trimmed) return { valid: false, error: "Phone number is required" };
      if (!validatePhoneNumber(trimmed)) {
        return { valid: false, error: "Invalid phone number format" };
      }
      return { valid: true };

    case "password":
      if (!trimmed) return { valid: false, error: "Password is required" };
      if (trimmed.length < 6) {
        return {
          valid: false,
          error: "Password must be at least 6 characters",
        };
      }
      if (trimmed.length > 128) {
        return { valid: false, error: "Password is too long" };
      }
      return { valid: true };

    case "text":
      if (!trimmed) return { valid: false, error: "This field is required" };
      if (trimmed.length > 500) {
        return { valid: false, error: "Text is too long (max 500 characters)" };
      }
      return { valid: true };

    default:
      return { valid: false, error: "Unknown input type" };
  }
}

// Batch validation
export function validateForm(
  values: Record<string, string>,
  schema: Record<string, "email" | "phone" | "text" | "password">
): Record<string, string> {
  const errors: Record<string, string> = {};

  for (const [field, type] of Object.entries(schema)) {
    const result = validateInput(values[field] || "", type);
    if (!result.valid && result.error) {
      errors[field] = result.error;
    }
  }

  return errors;
}