/**
 * API Helper Functions
 */

import { TRPCError } from "@trpc/server";
import { ENV } from "@/config/env";

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: number;
}

export interface ApiErrorResponse {
  code: string;
  message: string;
  details?: Record<string, any>;
}

/**
 * Format API Error
 */
export function formatApiError(error: unknown): ApiErrorResponse {
  if (error instanceof TRPCError) {
    return {
      code: error.code,
      message: error.message,
    };
  }

  if (error instanceof Error) {
    return {
      code: "INTERNAL_ERROR",
      message: error.message,
    };
  }

  return {
    code: "UNKNOWN_ERROR",
    message: "An unexpected error occurred",
  };
}

/**
 * Create API Response
 */
export function createApiResponse<T>(
  data: T,
  success: boolean = true
): ApiResponse<T> {
  return {
    success,
    data: success ? data : undefined,
    timestamp: Date.now(),
  };
}

/**
 * Create Error Response
 */
export function createErrorResponse(error: unknown): ApiResponse<never> {
  const formattedError = formatApiError(error);
  return {
    success: false,
    error: formattedError.message,
    timestamp: Date.now(),
  };
}

/**
 * Retry Logic for API Calls
 */
export async function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  delayMs: number = 1000
): Promise<T> {
  let lastError: Error | null = null;

  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      if (i < maxRetries - 1) {
        await new Promise((resolve) => setTimeout(resolve, delayMs));
      }
    }
  }

  throw lastError || new Error("Max retries exceeded");
}

/**
 * Log API Activity
 */
export function logApiActivity(
  action: string,
  details: Record<string, any>,
  level: "info" | "warn" | "error" = "info"
) {
  if (ENV.DEBUG) {
    console[level](`[API] ${action}:`, details);
  }
}