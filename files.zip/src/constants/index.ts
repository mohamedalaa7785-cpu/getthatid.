/**
 * Application Constants
 */

// Phone Number Categories
export const PHONE_CATEGORIES = {
  SPAM: "spam",
  BUSINESS: "business",
  PERSONAL: "personal",
} as const;

export const CATEGORY_COLORS = {
  spam: "bg-red-900 text-red-200",
  business: "bg-blue-900 text-blue-200",
  personal: "bg-green-900 text-green-200",
} as const;

// Interaction Actions
export const INTERACTION_ACTIONS = {
  AGREE: "agree",
  DISAGREE: "disagree",
  REPORT: "report",
} as const;

// User Roles
export const USER_ROLES = {
  USER: "user",
  ADMIN: "admin",
} as const;

// Sort Options
export const SORT_OPTIONS = [
  { value: "recent", label: "Most Recent" },
  { value: "popular", label: "Most Popular" },
  { value: "reported", label: "Most Reported" },
] as const;

// Badge Thresholds
export const BADGE_THRESHOLDS = {
  EXPERT: 1000,
  TRUSTED: 500,
  CONTRIBUTOR: 100,
  ACTIVE: 10,
} as const;

// Error Messages
export const ERROR_MESSAGES = {
  UNAUTHORIZED: "You must be logged in to perform this action",
  FORBIDDEN: "You don't have permission to access this resource",
  NOT_FOUND: "Resource not found",
  VALIDATION_ERROR: "Please check your input and try again",
  SERVER_ERROR: "Something went wrong. Please try again later",
  NETWORK_ERROR: "Network error. Please check your connection",
  INVALID_EMAIL: "Please enter a valid email address",
  INVALID_PHONE: "Please enter a valid phone number",
  INVALID_PASSWORD: "Password must be at least 6 characters",
  EMAIL_EXISTS: "This email is already registered",
  PHONE_EXISTS: "This phone number already exists in our database",
} as const;

// Success Messages
export const SUCCESS_MESSAGES = {
  LOGIN: "✓ Logged in successfully",
  LOGOUT: "✓ Logged out successfully",
  SIGNUP: "✓ Account created successfully",
  UPDATE: "✓ Updated successfully",
  DELETE: "✓ Deleted successfully",
  ADD_NUMBER: "✓ Phone number added successfully",
  INTERACTION: "✓ Your feedback has been recorded",
} as const;

// Local Storage Keys
export const STORAGE_KEYS = {
  SEARCH_HISTORY: "searchHistory",
  USER_PREFERENCES: "userPreferences",
  THEME: "theme",
  SESSION: "session",
} as const;

// Date Formats
export const DATE_FORMATS = {
  SHORT: "MMM d, yyyy",
  LONG: "MMMM d, yyyy",
  TIME: "h:mm a",
  FULL: "MMMM d, yyyy h:mm a",
} as const;

// HTTP Status Codes
export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  SERVER_ERROR: 500,
  SERVICE_UNAVAILABLE: 503,
} as const;