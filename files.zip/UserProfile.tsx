import { useAuth } from "@/_core/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { User, Trophy, TrendingUp, Clock } from "lucide-react";

export default function UserProfile() {
  const { user, isAuthenticated } = useAuth();
  const reputationQuery = trpc.reputation.getReputation.useQuery(
    { userId: user?.id || 0 },
    { enabled: isAuthenticated && !!user }
  );
  const badgeQuery = trpc.reputation.getBadge.useQuery(
    { userId: user?.id || 0 },
    { enabled: isAuthenticated && !!user }
  );

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <Card className="bg-gray-900 border-gray-700 p-8">
          <p className="text-gray-400 mb-4">Please login to view your profile</p>
          <Link href="/login">
            <Button className="bg-white text-black hover:bg-gray-200">Login</Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <nav className="border-b border-gray-800 py-4">
        <div className="max-w-6xl mx-auto px-4 flex justify-between items-center">
          <Link href="/">
            <a className="text-2xl font-bold">GET THAT ID</a>
          </Link>
          <Link href="/">
            <Button variant="outline">Back to Home</Button>
          </Link>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto py-12 px-4">
        <h1 className="text-4xl font-bold mb-8">Your Profile</h1>

        {/* User Info */}
        <Card className="bg-gray-900 border-gray-700 p-6 mb-8">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                <User size={32} />
              </div>
              <div>
                <h2 className="text-2xl font-bold">{user.name || "Anonymous"}</h2>
                <p className="text-gray-400">{user.email}</p>
                {user.phone && <p className="text-gray-400">{user.phone}</p>}
              </div>
            </div>
          </div>
        </Card>

        {/* Reputation Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card className="bg-gray-900 border-gray-700 p-6">
            <div className="flex items-center gap-3 mb-4">
              <Trophy size={24} className="text-yellow-500" />
              <h3 className="text-xl font-bold">Reputation Score</h3>
            </div>
            <p className="text-4xl font-bold text-yellow-500 mb-2">
              {reputationQuery.data?.reputationScore || 0}
            </p>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-400">Badge:</span>
              <span
                className={`px-3 py-1 rounded text-sm font-semibold ${
                  badgeQuery.data?.badge === "expert"
                    ? "bg-yellow-900 text-yellow-200"
                    : badgeQuery.data?.badge === "trusted"
                    ? "bg-blue-900 text-blue-200"
                    : badgeQuery.data?.badge === "contributor"
                    ? "bg-green-900 text-green-200"
                    : "bg-gray-700 text-gray-200"
                }`}
              >
                {badgeQuery.data?.badge || "New"}
              </span>
            </div>
          </Card>

          <Card className="bg-gray-900 border-gray-700 p-6">
            <div className="flex items-center gap-3 mb-4">
              <TrendingUp size={24} className="text-green-500" />
              <h3 className="text-xl font-bold">Accuracy Rating</h3>
            </div>
            <p className="text-4xl font-bold text-green-500">
              {reputationQuery.data?.accuracyRating || 0}%
            </p>
            <p className="text-sm text-gray-400 mt-2">Based on your interactions</p>
          </Card>
        </div>

        {/* Stats */}
        <Card className="bg-gray-900 border-gray-700 p-6">
          <h3 className="text-xl font-bold mb-4">Account Information</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-gray-400 text-sm">Member Since</p>
              <p className="font-semibold">{new Date(user.createdAt).toLocaleDateString()}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Last Active</p>
              <p className="font-semibold">{new Date(user.updatedAt).toLocaleDateString()}</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Email Status</p>
              <p className="font-semibold text-green-500">Verified</p>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Account Status</p>
              <p className="font-semibold text-green-500">Active</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}