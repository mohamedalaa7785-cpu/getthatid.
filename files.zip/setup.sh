#!/bin/bash

echo "🚀 Get That ID - Setup Script"
echo "=============================="

# Check Node.js
echo "📦 Checking Node.js..."
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install it first."
    exit 1
fi

echo "✅ Node.js $(node -v) found"

# Install dependencies
echo ""
echo "📥 Installing dependencies..."
npm install

# Setup environment
echo ""
echo "⚙️ Setting up environment..."
if [ ! -f .env.local ]; then
    cp .env.example .env.local
    echo "✅ Created .env.local"
else
    echo "ℹ️ .env.local already exists"
fi

# Build
echo ""
echo "🔨 Building project..."
npm run build

# Success
echo ""
echo "✅ Setup complete!"
echo ""
echo "🚀 To start development:"
echo "   npm run dev"
echo ""
echo "📱 Open: http://localhost:5173"