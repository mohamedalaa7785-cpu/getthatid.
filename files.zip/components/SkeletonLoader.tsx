export function NumberSkeleton() {
  return (
    <div className="bg-gray-900 border border-gray-700 rounded-lg p-6 space-y-4 animate-pulse">
      <div className="h-8 bg-gray-800 rounded w-1/2" />
      <div className="h-4 bg-gray-800 rounded w-1/3" />
      <div className="grid grid-cols-3 gap-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="bg-gray-800 rounded h-20" />
        ))}
      </div>
    </div>
  );
}

export function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-3">
      {[...Array(rows)].map((_, i) => (
        <div key={i} className="h-12 bg-gray-800 rounded animate-pulse" />
      ))}
    </div>
  );
}