import { useState, useEffect, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Phone, History, Loader } from "lucide-react";

interface Suggestion {
  id: number;
  phoneNumber: string;
  name: string;
  category: "spam" | "business" | "personal";
  agreeCount: number;
}

export default function SearchSuggestions({
  onSelect,
}: {
  onSelect: (phoneNumber: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const searchMutation = trpc.numbers.advancedSearch.useMutation();

  // Load recent searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("recentSearches");
    if (saved) {
      try {
        setRecentSearches(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load recent searches");
      }
    }
  }, []);

  // Debounced search
  const handleSearch = useCallback(
    async (searchTerm: string) => {
      if (searchTerm.length < 2) {
        setSuggestions([]);
        setIsLoading(false);
        return;
      }

      setIsLoading(true);
      try {
        const result = await searchMutation.mutateAsync({
          query: searchTerm,
          limit: 5,
        });
        setSuggestions(result.results as Suggestion[]);
      } catch (error) {
        console.error("Search error:", error);
        setSuggestions([]);
      } finally {
        setIsLoading(false);
      }
    },
    [searchMutation]
  );

  // Debounce logic
  useEffect(() => {
    const timer = setTimeout(() => {
      if (query) {
        handleSearch(query);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [query, handleSearch]);

  const handleQueryChange = (value: string) => {
    setQuery(value);
    setIsOpen(true);
  };

  const handleSelectSuggestion = (phoneNumber: string) => {
    onSelect(phoneNumber);

    // Save to recent searches
    const updated = [
      phoneNumber,
      ...recentSearches.filter((s) => s !== phoneNumber),
    ].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem("recentSearches", JSON.stringify(updated));

    setQuery("");
    setSuggestions([]);
    setIsOpen(false);
  };

  return (
    <div className="relative w-full">
      <Input
        type="tel"
        placeholder="Search phone numbers..."
        value={query}
        onChange={(e) => handleQueryChange(e.target.value)}
        onFocus={() => setIsOpen(true)}
        className="bg-gray-900 border-gray-700 text-white placeholder-gray-500"
      />

      {isOpen && (
        <Card className="absolute top-12 left-0 right-0 bg-gray-900 border-gray-700 max-h-96 overflow-y-auto z-50 shadow-lg">
          {/* Loading State */}
          {isLoading && query.length >= 2 && (
            <div className="px-4 py-6 flex justify-center">
              <Loader size={20} className="animate-spin text-gray-400" />
            </div>
          )}

          {/* Suggestions */}
          {!isLoading && query.length >= 2 && suggestions.length > 0 && (
            <div>
              <div className="px-4 py-2 text-xs font-semibold text-gray-400 border-b border-gray-700 bg-gray-800">
                SEARCH RESULTS ({suggestions.length})
              </div>
              {suggestions.map((suggestion) => (
                <button
                  key={suggestion.id}
                  onClick={() => handleSelectSuggestion(suggestion.phoneNumber)}
                  className="w-full text-left px-4 py-3 hover:bg-gray-800 border-b border-gray-800 last:border-b-0 transition"
                >
                  <div className="flex items-center gap-3">
                    <Phone size={16} className="text-gray-500 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{suggestion.name}</p>
                      <p className="text-sm text-gray-400 font-mono">
                        {suggestion.phoneNumber}
                      </p>
                    </div>
                    <span
                      className={`text-xs px-2 py-1 rounded flex-shrink-0 ${
                        suggestion.category === "spam"
                          ? "bg-red-900 text-red-200"
                          : suggestion.category === "business"
                          ? "bg-blue-900 text-blue-200"
                          : "bg-green-900 text-green-200"
                      }`}
                    >
                      {suggestion.category}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          )}

          {/* Recent Searches */}
          {!query && recentSearches.length > 0 && (
            <div>
              <div className="px-4 py-2 text-xs font-semibold text-gray-400 border-b border-gray-700 bg-gray-800">
                RECENT SEARCHES
              </div>
              {recentSearches.map((search, index) => (
                <button
                  key={index}
                  onClick={() => handleSelectSuggestion(search)}
                  className="w-full text-left px-4 py-3 hover:bg-gray-800 border-b border-gray-800 last:border-b-0 flex items-center gap-2 transition"
                >
                  <History size={16} className="text-gray-500" />
                  <span>{search}</span>
                </button>
              ))}
            </div>
          )}

          {/* No results */}
          {!isLoading && query.length >= 2 && suggestions.length === 0 && (
            <div className="px-4 py-6 text-center text-gray-400">
              <p>No results found for "{query}"</p>
            </div>
          )}

          {/* Empty state */}
          {!query && recentSearches.length === 0 && (
            <div className="px-4 py-6 text-center text-gray-500 text-sm">
              <p>Start typing to search...</p>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}