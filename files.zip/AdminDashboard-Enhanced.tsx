import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Trash2, Lock, Unlock, Download, BarChart3 } from "lucide-react";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<"stats" | "numbers" | "users">("stats");
  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const statsQuery = trpc.admin.getStats.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const numbersQuery = trpc.admin.getAllNumbers.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const usersQuery = trpc.admin.getAllUsers.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const deleteNumberMutation = trpc.admin.deleteNumber.useMutation();
  const blockUserMutation = trpc.admin.blockUser.useMutation();
  const unblockUserMutation = trpc.admin.unblockUser.useMutation();
  const exportMutation = trpc.export.exportNumbers.useMutation();
  const utils = trpc.useUtils();

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center">
        <Card className="bg-gray-900 border-gray-700 p-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-gray-400 mb-6">You must be an admin to access this page.</p>
          <Link href="/">
            <a>
              <Button className="bg-white text-black hover:bg-gray-200">Back to Home</Button>
            </a>
          </Link>
        </Card>
      </div>
    );
  }

  const handleDeleteNumber = async (numberId: number) => {
    if (confirm("Are you sure you want to delete this number?")) {
      try {
        await deleteNumberMutation.mutateAsync({ numberId });
        utils.admin.getAllNumbers.invalidate();
      } catch (error) {
        console.error("Failed to delete number:", error);
      }
    }
  };

  const handleBlockUser = async (userId: number) => {
    try {
      await blockUserMutation.mutateAsync({ userId });
      utils.admin.getAllUsers.invalidate();
    } catch (error) {
      console.error("Failed to block user:", error);
    }
  };

  const handleUnblockUser = async (userId: number) => {
    try {
      await unblockUserMutation.mutateAsync({ userId });
      utils.admin.getAllUsers.invalidate();
    } catch (error) {
      console.error("Failed to unblock user:", error);
    }
  };

  const handleExport = async (format: "csv" | "json") => {
    try {
      const result = await exportMutation.mutateAsync({ format });
      const element = document.createElement("a");
      element.setAttribute(
        "href",
        `data:text/${format === "csv" ? "csv" : "json"};charset=utf-8,${encodeURIComponent(result.data)}`
      );
      element.setAttribute("download", result.filename);
      element.style.display = "none";
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    } catch (error) {
      console.error("Failed to export:", error);
    }
  };

  // Pagination helpers
  const paginatedNumbers = numbersQuery.data?.slice(
    (pageNumber - 1) * pageSize,
    pageNumber * pageSize
  ) || [];
  const totalNumbersPages = Math.ceil((numbersQuery.data?.length || 0) / pageSize);

  const paginatedUsers = usersQuery.data?.slice(
    (pageNumber - 1) * pageSize,
    pageNumber * pageSize
  ) || [];
  const totalUsersPages = Math.ceil((usersQuery.data?.length || 0) / pageSize);

  const categoryData = statsQuery.data ? [
    { name: "Spam", value: statsQuery.data.categoryBreakdown.spam },
    { name: "Business", value: statsQuery.data.categoryBreakdown.business },
    { name: "Personal", value: statsQuery.data.categoryBreakdown.personal },
  ] : [];

  const COLORS = ["#ef4444", "#3b82f6", "#22c55e"];

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Navigation */}
      <nav className="border-b border-gray-800 py-4">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
          <Link href="/">
            <a className="text-2xl font-bold">GET THAT ID</a>
          </Link>
          <div className="flex gap-6 items-center">
            <Link href="/">
              <a className="hover:text-gray-400">HOME</a>
            </Link>
            <span className="text-gray-400">Admin Panel</span>
          </div>
        </div>
      </nav>

      {/* Admin Panel */}
      <div className="flex-1 max-w-7xl mx-auto w-full py-8 px-4">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold">Admin Dashboard</h1>
          <div className="flex gap-2">
            <Button
              onClick={() => handleExport("csv")}
              className="bg-green-600 hover:bg-green-700"
            >
              <Download size={16} className="mr-2" />
              Export CSV
            </Button>
            <Button
              onClick={() => handleExport("json")}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Download size={16} className="mr-2" />
              Export JSON
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-gray-800">
          {["stats", "numbers", "users"].map((tab) => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab as any);
                setPageNumber(1);
              }}
              className={`px-4 py-2 font-medium capitalize transition ${
                activeTab === tab
                  ? "border-b-2 border-white"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Statistics Tab */}
        {activeTab === "stats" && (
          <div className="space-y-8">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              <Card className="bg-gray-900 border-gray-700 p-6">
                <p className="text-gray-400 text-sm">Total Users</p>
                <p className="text-3xl font-bold">{statsQuery.data?.totalUsers || 0}</p>
              </Card>
              <Card className="bg-gray-900 border-gray-700 p-6">
                <p className="text-gray-400 text-sm">Blocked Users</p>
                <p className="text-3xl font-bold text-red-500">
                  {statsQuery.data?.blockedUsers || 0}
                </p>
              </Card>
              <Card className="bg-gray-900 border-gray-700 p-6">
                <p className="text-gray-400 text-sm">Total Numbers</p>
                <p className="text-3xl font-bold">{statsQuery.data?.totalNumbers || 0}</p>
              </Card>
              <Card className="bg-gray-900 border-gray-700 p-6">
                <p className="text-gray-400 text-sm">Total Reports</p>
                <p className="text-3xl font-bold text-yellow-500">
                  {statsQuery.data?.totalReports || 0}
                </p>
              </Card>
              <Card className="bg-gray-900 border-gray-700 p-6">
                <p className="text-gray-400 text-sm">Total Agreements</p>
                <p className="text-3xl font-bold text-green-500">
                  {statsQuery.data?.totalAgreements || 0}
                </p>
              </Card>
              <Card className="bg-gray-900 border-gray-700 p-6">
                <p className="text-gray-400 text-sm">Total Disagreements</p>
                <p className="text-3xl font-bold text-red-500">
                  {statsQuery.data?.totalDisagreements || 0}
                </p>
              </Card>
            </div>

            {/* Charts */}
            {statsQuery.data && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Category Distribution */}
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <BarChart3 size={20} />
                    Category Distribution
                  </h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={categoryData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="name" stroke="#9ca3af" />
                      <YAxis stroke="#9ca3af" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1f2937",
                          border: "1px solid #374151",
                          borderRadius: "8px",
                        }}
                      />
                      <Bar dataKey="value" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </Card>

                {/* Interaction Distribution */}
                <Card className="bg-gray-900 border-gray-700 p-6">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <BarChart3 size={20} />
                    Interaction Distribution
                  </h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={[
                          { name: "Agree", value: statsQuery.data.totalAgreements },
                          { name: "Disagree", value: statsQuery.data.totalDisagreements },
                          { name: "Report", value: statsQuery.data.totalReports },
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, value }) => `${name}: ${value}`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        <Cell fill="#22c55e" />
                        <Cell fill="#ef4444" />
                        <Cell fill="#eab308" />
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1f2937",
                          border: "1px solid #374151",
                          borderRadius: "8px",
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </Card>
              </div>
            )}
          </div>
        )}

        {/* Numbers Tab */}
        {activeTab === "numbers" && (
          <div>
            {numbersQuery.isLoading ? (
              <p className="text-gray-400">Loading...</p>
            ) : paginatedNumbers.length > 0 ? (
              <>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b border-gray-700">
                      <tr>
                        <th className="text-left py-3 px-4">Phone Number</th>
                        <th className="text-left py-3 px-4">Name</th>
                        <th className="text-left py-3 px-4">Category</th>
                        <th className="text-left py-3 px-4">Agree</th>
                        <th className="text-left py-3 px-4">Disagree</th>
                        <th className="text-left py-3 px-4">Reports</th>
                        <th className="text-left py-3 px-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedNumbers.map((number: any) => (
                        <tr
                          key={number.id}
                          className="border-b border-gray-800 hover:bg-gray-900 transition"
                        >
                          <td className="py-3 px-4 font-mono text-sm">{number.phoneNumber}</td>
                          <td className="py-3 px-4">{number.name}</td>
                          <td className="py-3 px-4 capitalize">
                            <span
                              className={`px-2 py-1 rounded text-xs ${
                                number.category === "spam"
                                  ? "bg-red-900 text-red-200"
                                  : number.category === "business"
                                  ? "bg-blue-900 text-blue-200"
                                  : "bg-green-900 text-green-200"
                              }`}
                            >
                              {number.category}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-green-500 font-semibold">
                            {number.agreeCount}
                          </td>
                          <td className="py-3 px-4 text-red-500 font-semibold">
                            {number.disagreeCount}
                          </td>
                          <td className="py-3 px-4 text-yellow-500 font-semibold">
                            {number.reportCount}
                          </td>
                          <td className="py-3 px-4">
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDeleteNumber(number.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              <Trash2 size={16} />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                <div className="mt-4 flex justify-center items-center gap-2">
                  <Button
                    onClick={() => setPageNumber(Math.max(1, pageNumber - 1))}
                    disabled={pageNumber === 1}
                    variant="outline"
                  >
                    Previous
                  </Button>
                  <span className="text-gray-400">
                    Page {pageNumber} of {totalNumbersPages}
                  </span>
                  <Button
                    onClick={() => setPageNumber(Math.min(totalNumbersPages, pageNumber + 1))}
                    disabled={pageNumber === totalNumbersPages}
                    variant="outline"
                  >
                    Next
                  </Button>
                </div>
              </>
            ) : (
              <p className="text-gray-400">No numbers found</p>
            )}
          </div>
        )}

        {/* Users Tab */}
        {activeTab === "users" && (
          <div>
            {usersQuery.isLoading ? (
              <p className="text-gray-400">Loading...</p>
            ) : paginatedUsers.length > 0 ? (
              <>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b border-gray-700">
                      <tr>
                        <th className="text-left py-3 px-4">Email</th>
                        <th className="text-left py-3 px-4">Name</th>
                        <th className="text-left py-3 px-4">Role</th>
                        <th className="text-left py-3 px-4">Status</th>
                        <th className="text-left py-3 px-4">Created</th>
                        <th className="text-left py-3 px-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedUsers.map((u: any) => (
                        <tr
                          key={u.id}
                          className="border-b border-gray-800 hover:bg-gray-900 transition"
                        >
                          <td className="py-3 px-4 font-mono text-sm">{u.email}</td>
                          <td className="py-3 px-4">{u.name || "-"}</td>
                          <td className="py-3 px-4 capitalize">
                            <span
                              className={`px-2 py-1 rounded text-xs ${
                                u.role === "admin"
                                  ? "bg-purple-900 text-purple-200"
                                  : "bg-gray-700 text-gray-200"
                              }`}
                            >
                              {u.role}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`font-medium ${
                                u.isBlocked ? "text-red-500" : "text-green-500"
                              }`}
                            >
                              {u.isBlocked ? "Blocked" : "Active"}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-sm text-gray-400">
                            {new Date(u.createdAt).toLocaleDateString()}
                          </td>
                          <td className="py-3 px-4">
                            {u.isBlocked ? (
                              <Button
                                size="sm"
                                onClick={() => handleUnblockUser(u.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <Unlock size={16} />
                              </Button>
                            ) : (
                              <Button
                                size="sm"
                                onClick={() => handleBlockUser(u.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                <Lock size={16} />
                              </Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                <div className="mt-4 flex justify-center items-center gap-2">
                  <Button
                    onClick={() => setPageNumber(Math.max(1, pageNumber - 1))}
                    disabled={pageNumber === 1}
                    variant="outline"
                  >
                    Previous
                  </Button>
                  <span className="text-gray-400">
                    Page {pageNumber} of {totalUsersPages}
                  </span>
                  <Button
                    onClick={() => setPageNumber(Math.min(totalUsersPages, pageNumber + 1))}
                    disabled={pageNumber === totalUsersPages}
                    variant="outline"
                  >
                    Next
                  </Button>
                </div>
              </>
            ) : (
              <p className="text-gray-400">No users found</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}