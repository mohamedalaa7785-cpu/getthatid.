# Contributing to Get That ID

Thank you for considering contributing to Get That ID! Here's how you can help.

## Getting Started

1. Fork the repository
2. Clone your fork
3. Create a feature branch
4. Make your changes
5. Submit a pull request

## Code Guidelines

- Use TypeScript for all code
- Follow the existing code style
- Write meaningful commit messages
- Add tests for new features
- Update documentation as needed

## Commit Messages
