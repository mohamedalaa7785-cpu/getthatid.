#!/bin/bash

# Create and initialize git repository
git init Get-That-ID-Phone-Lookup-App
cd Get-That-ID-Phone-Lookup-App

# Configure git
git config user.name "Your Name"
git config user.email "your@email.com"

# Create directory structure
mkdir -p src/{pages,components,hooks,utils,config,services,lib,server/routers,contexts}
mkdir -p public
mkdir -p docs

# Initialize as git repo
git add .
git commit -m "Initial commit: Project structure"

# Create and push to remote
# git remote add origin https://github.com/mohamedalaa7785-cpu/Get-That-ID-Phone-Lookup-App.git
# git branch -M main
# git push -u origin main