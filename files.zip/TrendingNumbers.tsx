import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { TrendingUp, AlertTriangle } from "lucide-react";

interface TrendingNumber {
  id: number;
  phoneNumber: string;
  name: string;
  category: "spam" | "business" | "personal";
  agreeCount: number;
  reportCount: number;
}

export default function TrendingNumbers({ onSelect }: { onSelect: (number: TrendingNumber) => void }) {
  const { data: trending, isLoading } = trpc.numbers.getTrending.useQuery({ limit: 5 });

  if (isLoading) {
    return (
      <Card className="bg-gray-900 border-gray-700 p-6">
        <p className="text-gray-400">Loading trending numbers...</p>
      </Card>
    );
  }

  if (!trending || trending.length === 0) {
    return null;
  }

  return (
    <Card className="bg-gray-900 border-gray-700 p-6">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp size={20} className="text-yellow-500" />
        <h3 className="text-xl font-bold">Trending This Week</h3>
      </div>

      <div className="space-y-3">
        {trending.map((number: any, index) => (
          <button
            key={number.id}
            onClick={() => onSelect(number)}
            className="w-full text-left p-3 bg-gray-800 hover:bg-gray-700 rounded transition border border-gray-700 hover:border-gray-600"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-yellow-500">#{index + 1}</span>
                  <p className="font-semibold">{number.name}</p>
                  <span className={`text-xs px-2 py-0.5 rounded ${
                    number.category === "spam" ? "bg-red-900 text-red-200" :
                    number.category === "business" ? "bg-blue-900 text-blue-200" :
                    "bg-green-900 text-green-200"
                  }`}>
                    {number.category}
                  </span>
                </div>
                <p className="text-sm text-gray-400 mt-1">{number.phoneNumber}</p>
              </div>
              <div className="text-right text-sm">
                <p className="text-green-500 font-semibold">{number.agreeCount} agrees</p>
                {number.reportCount > 0 && (
                  <p className="text-red-500 flex items-center gap-1 justify-end">
                    <AlertTriangle size={14} />
                    {number.reportCount} reports
                  </p>
                )}
              </div>
            </div>
          </button>
        ))}
      </div>
    </Card>
  );
}