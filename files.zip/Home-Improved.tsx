import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { Search, AlertTriangle, CheckCircle, XCircle, Flag, Loader } from "lucide-react";
import SearchSuggestions from "@/components/SearchSuggestions";
import TrendingNumbers from "@/components/TrendingNumbers";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [phoneNumber, setPhoneNumber] = useState("");
  const [searchResults, setSearchResults] = useState<any>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState("");

  const utils = trpc.useUtils();

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSearchResults(null);

    if (!phoneNumber.trim()) {
      setError("Please enter a phone number");
      return;
    }

    setIsSearching(true);
    try {
      const result = await utils.numbers.search.fetch({ phoneNumber });
      setSearchResults(result);
    } catch (err: any) {
      setError(err.message || "Search failed");
    } finally {
      setIsSearching(false);
    }
  };

  const handleSuggestionSelect = (selectedPhoneNumber: string) => {
    setPhoneNumber(selectedPhoneNumber);
    // Auto-search
    setIsSearching(true);
    utils.numbers.search.fetch({ phoneNumber: selectedPhoneNumber })
      .then(result => {
        setSearchResults(result);
        setError("");
      })
      .catch((err: any) => {
        setError(err.message || "Search failed");
      })
      .finally(() => setIsSearching(false));
  };

  const handleTrendingSelect = (number: any) => {
    setPhoneNumber(number.phoneNumber);
    setSearchResults({
      found: true,
      data: number
    });
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Navigation */}
      <nav className="border-b border-gray-800 py-4 sticky top-0 bg-black/95 backdrop-blur z-40">
        <div className="max-w-6xl mx-auto px-4 flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold hover:text-gray-300 transition">
            GET THAT ID
          </Link>
          <div className="flex gap-6 items-center">
            <Link href="/" className="hover:text-gray-400 transition">HOME</Link>
            <Link href="/contact" className="hover:text-gray-400 transition">CONTACT</Link>
            <Link href="/privacy" className="hover:text-gray-400 transition">PRIVACY</Link>
            <Link href="/terms" className="hover:text-gray-400 transition">TERMS</Link>
            {isAuthenticated ? (
              <>
                <Link href="/profile" className="hover:text-gray-400 transition">PROFILE</Link>
                {user?.role === "admin" && (
                  <Link href="/admin" className="hover:text-gray-400 transition">ADMIN</Link>
                )}
              </>
            ) : (
              <>
                <Link href="/login" className="hover:text-gray-400 transition">LOGIN</Link>
                <Link href="/signup" className="hover:text-gray-400 transition">SIGNUP</Link>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="flex-1 flex flex-col items-center justify-center py-20">
        <div className="text-center mb-12">
          <p className="text-gray-500 text-sm mb-4">BY HAMO</p>
          <h1 className="text-6xl font-bold mb-6">Get That ID</h1>
          <p className="text-gray-400 text-lg max-w-2xl">
            Identify unknown callers. Report spam. Protect your phone. The premium caller identification service.
          </p>
        </div>

        {/* Search Box */}
        <form onSubmit={handleSearch} className="w-full max-w-2xl px-4 mb-12">
          <div className="flex gap-2 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 text-gray-500 pointer-events-none" size={20} />
              <SearchSuggestions onSelect={handleSuggestionSelect} />
            </div>
            <Button
              type="submit"
              disabled={isSearching}
              className="bg-white text-black hover:bg-gray-200 px-8 flex items-center gap-2"
            >
              {isSearching ? (
                <>
                  <Loader size={16} className="animate-spin" />
                  Searching...
                </>
              ) : (
                "LOOK UP"
              )}
            </Button>
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
        </form>

        {/* Search Results */}
        {searchResults && (
          <div className="w-full max-w-2xl px-4 mb-12">
            {searchResults.found ? (
              <SearchResultCard
                data={searchResults.data}
                isAuthenticated={isAuthenticated}
              />
            ) : (
              <Card className="bg-gray-900 border-gray-700 p-6">
                <div className="text-center">
                  <AlertTriangle className="mx-auto mb-4 text-gray-500" size={48} />
                  <h3 className="text-xl font-bold mb-2">Number Not Found</h3>
                  <p className="text-gray-400 mb-6">
                    This phone number is not in our database yet.
                  </p>
                  {isAuthenticated && (
                    <Link href="/add-number">
                      <Button className="bg-white text-black hover:bg-gray-200">
                        Add This Number
                      </Button>
                    </Link>
                  )}
                </div>
              </Card>
            )}
          </div>
        )}

        {/* Trending Numbers */}
        <div className="w-full max-w-2xl px-4 mb-12">
          <TrendingNumbers onSelect={handleTrendingSelect} />
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gray-900 py-20">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-12">Why Get That ID</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              {
                icon: Search,
                title: "Instant Lookup",
                desc: "Search any phone number and get instant identification results from our extensive database.",
              },
              {
                icon: AlertTriangle,
                title: "Spam Protection",
                desc: "Community-powered spam detection keeps you safe from unwanted and fraudulent calls.",
              },
              {
                icon: CheckCircle,
                title: "Community Labels",
                desc: "Verified labels from real users help you know exactly who's calling before you answer.",
              },
              {
                icon: Flag,
                title: "Report & Block",
                desc: "Report spam numbers and contribute to keeping the community safe from scam callers.",
              },
            ].map((feature, i) => (
              <div key={i} className="text-center">
                <feature.icon className="mx-auto mb-4 text-gray-500" size={32} />
                <h3 className="font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-20">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { num: "01", title: "Enter Number", desc: "Type any phone number you want to identify into our search bar." },
              { num: "02", title: "Get Results", desc: "Instantly see caller identity, community labels, and spam reports." },
              { num: "03", title: "Take Action", desc: "Report spam, confirm labels, or add your own identification tag." },
            ].map((step, i) => (
              <div key={i} className="text-center">
                <div className="text-5xl font-bold text-gray-700 mb-4">{step.num}</div>
                <h4 className="text-xl font-bold mb-2">{step.title}</h4>
                <p className="text-gray-400">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-12 bg-gray-950">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">GET THAT ID</h4>
              <p className="text-gray-400 text-sm">
                Premium caller identification service by HAMO. Identify unknown callers and protect yourself from spam.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">QUICK LINKS</h4>
              <ul className="text-gray-400 text-sm space-y-2">
                <li><Link href="/" className="hover:text-white transition">Home</Link></li>
                <li><Link href="/contact" className="hover:text-white transition">Contact</Link></li>
                <li><Link href="/privacy" className="hover:text-white transition">Privacy Policy</Link></li>
                <li><Link href="/terms" className="hover:text-white transition">Terms of Service</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">CONTACT</h4>
              <p className="text-gray-400 text-sm">
                <a href="mailto:contact@getthatid.com" className="hover:text-white transition">
                  contact@getthatid.com
                </a>
              </p>
              <p className="text-gray-400 text-sm">
                <a href="mailto:privacy@getthatid.com" className="hover:text-white transition">
                  privacy@getthatid.com
                </a>
              </p>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-500 text-sm">
            <p>© 2026 Get That ID — by HAMO. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function SearchResultCard({
  data,
  isAuthenticated,
}: {
  data: any;
  isAuthenticated: boolean;
}) {
  return (
    <Card className="bg-gray-900 border-gray-700 p-6">
      <div className="mb-4">
        <h2 className="text-2xl font-bold mb-2">{data.name}</h2>
        <p className="text-gray-400">{data.phoneNumber}</p>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-gray-800 p-4 rounded">
          <p className="text-gray-400 text-sm">Category</p>
          <p className="text-xl font-bold capitalize">{data.category}</p>
        </div>
        <div className="bg-gray-800 p-4 rounded">
          <p className="text-gray-400 text-sm">Agree</p>
          <p className="text-xl font-bold text-green-500">{data.agreeCount}</p>
        </div>
        <div className="bg-gray-800 p-4 rounded">
          <p className="text-gray-400 text-sm">Disagree</p>
          <p className="text-xl font-bold text-red-500">{data.disagreeCount}</p>
        </div>
      </div>

      <div className="bg-gray-800 p-4 rounded mb-6">
        <p className="text-gray-400 text-sm">Reports</p>
        <p className="text-xl font-bold text-yellow-500">{data.reportCount}</p>
      </div>

      {isAuthenticated && (
        <InteractionButtons numberId={data.id} />
      )}

      {!isAuthenticated && (
        <div className="bg-blue-900 border border-blue-700 p-4 rounded">
          <p className="text-blue-200">
            <Link href="/login">
              <a className="underline hover:text-blue-100">Sign in</a>
            </Link>
            {" "}to report or agree with this number.
          </p>
        </div>
      )}
    </Card>
  );
}

function InteractionButtons({
  numberId,
}: {
  numberId: number;
}) {
  const setActionMutation = trpc.interactions.setAction.useMutation();
  const utils = trpc.useUtils();
  const [currentAction, setCurrentAction] = useState<string | null>(null);

  const handleAction = async (action: "agree" | "disagree" | "report") => {
    try {
      await setActionMutation.mutateAsync({ numberId, action });
      setCurrentAction(action);
      utils.interactions.getByNumber.invalidate({ numberId });
      utils.numbers.search.invalidate();
    } catch (error) {
      console.error("Failed to record action:", error);
    }
  };

  return (
    <div className="flex gap-2">
      <Button
        onClick={() => handleAction("agree")}
        variant={currentAction === "agree" ? "default" : "outline"}
        className={currentAction === "agree" ? "bg-green-600 hover:bg-green-700" : ""}
      >
        <CheckCircle size={16} className="mr-2" />
        Agree
      </Button>
      <Button
        onClick={() => handleAction("disagree")}
        variant={currentAction === "disagree" ? "default" : "outline"}
        className={currentAction === "disagree" ? "bg-red-600 hover:bg-red-700" : ""}
      >
        <XCircle size={16} className="mr-2" />
        Disagree
      </Button>
      <Button
        onClick={() => handleAction("report")}
        variant={currentAction === "report" ? "default" : "outline"}
        className={currentAction === "report" ? "bg-yellow-600 hover:bg-yellow-700" : ""}
      >
        <Flag size={16} className="mr-2" />
        Report
      </Button>
    </div>
  );
}