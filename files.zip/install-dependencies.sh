# تشغيل هذا الأمر في terminal
npm install recharts dompurify clsx date-fns
npm install -D @types/dompurify

# تحقق من التثبيت
npm list recharts dompurify