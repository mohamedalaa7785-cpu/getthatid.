import { useState, useEffect, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Phone, History, Trending2 } from "lucide-react";

interface Suggestion {
  id: number;
  phoneNumber: string;
  name: string;
  category: "spam" | "business" | "personal";
  agreeCount: number;
}

export default function SearchSuggestions({
  onSelect,
}: {
  onSelect: (phoneNumber: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  const searchMutation = trpc.numbers.advancedSearch.useMutation();

  // Load recent searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("recentSearches");
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  }, []);

  // Debounced search
  const debounce = useCallback((fn: Function, delay: number) => {
    let timer: NodeJS.Timeout;
    return (...args: any[]) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), delay);
    };
  }, []);

  const handleSearch = useCallback(
    debounce(async (searchTerm: string) => {
      if (searchTerm.length < 2) {
        setSuggestions([]);
        return;
      }

      try {
        const result = await searchMutation.mutateAsync({
          query: searchTerm,
          limit: 5,
        });
        setSuggestions(result.results as Suggestion[]);
      } catch (error) {
        setSuggestions([]);
      }
    }, 300),
    [searchMutation, debounce]
  );

  useEffect(() => {
    handleSearch(query);
  }, [query, handleSearch]);

  const handleQueryChange = (value: string) => {
    setQuery(value);
    setIsOpen(true);
  };

  const handleSelectSuggestion = (phoneNumber: string) => {
    onSelect(phoneNumber);
    
    // Save to recent searches
    const updated = [phoneNumber, ...recentSearches.filter(s => s !== phoneNumber)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem("recentSearches", JSON.stringify(updated));
    
    setQuery("");
    setSuggestions([]);
    setIsOpen(false);
  };

  return (
    <div className="relative w-full">
      <Input
        type="tel"
        placeholder="Search phone numbers..."
        value={query}
        onChange={(e) => handleQueryChange(e.target.value)}
        onFocus={() => setIsOpen(true)}
        className="bg-gray-900 border-gray-700 text-white placeholder-gray-500"
      />

      {isOpen && (
        <Card className="absolute top-12 left-0 right-0 bg-gray-900 border-gray-700 max-h-96 overflow-y-auto z-50">
          {/* Suggestions */}
          {query.length >= 2 && suggestions.length > 0 && (
            <div>
              <div className="px-4 py-2 text-xs font-semibold text-gray-400 border-b border-gray-700">
                SUGGESTIONS
              </div>
              {suggestions.map((suggestion) => (
                <button
                  key={suggestion.id}
                  onClick={() => handleSelectSuggestion(suggestion.phoneNumber)}
                  className="w-full text-left px-4 py-3 hover:bg-gray-800 border-b border-gray-800 last:border-b-0 transition"
                >
                  <div className="flex items-center gap-3">
                    <Phone size={16} className="text-gray-500" />
                    <div className="flex-1">
                      <p className="font-medium">{suggestion.name}</p>
                      <p className="text-sm text-gray-400">{suggestion.phoneNumber}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded ${
                      suggestion.category === "spam" ? "bg-red-900" :
                      suggestion.category === "business" ? "bg-blue-900" :
                      "bg-green-900"
                    }`}>
                      {suggestion.category}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          )}

          {/* Recent Searches */}
          {!query && recentSearches.length > 0 && (
            <div>
              <div className="px-4 py-2 text-xs font-semibold text-gray-400 border-b border-gray-700">
                RECENT SEARCHES
              </div>
              {recentSearches.map((search, index) => (
                <button
                  key={index}
                  onClick={() => handleSelectSuggestion(search)}
                  className="w-full text-left px-4 py-3 hover:bg-gray-800 border-b border-gray-800 last:border-b-0 flex items-center gap-2 transition"
                >
                  <History size={16} className="text-gray-500" />
                  <span>{search}</span>
                </button>
              ))}
            </div>
          )}

          {/* No results */}
          {query.length >= 2 && suggestions.length === 0 && (
            <div className="px-4 py-6 text-center text-gray-400">
              <p>No results found for "{query}"</p>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}