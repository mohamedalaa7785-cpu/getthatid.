#!/bin/bash

# This script will create and push your repository to GitHub

echo "🚀 Starting GitHub Repository Creation..."

# Variables
GITHUB_USER="mohamedalaa7785-cpu"
REPO_NAME="Get-That-ID-Phone-Lookup-App"
REPO_URL="https://github.com/$GITHUB_USER/$REPO_NAME.git"

# Initialize git
git init
git add .
git commit -m "Initial commit: Complete Get That ID App

- Added all frontend components (SearchSuggestions, TrendingNumbers, etc)
- Added all pages (Home, Admin, UserProfile, AddNumber)
- Added custom hooks for validation and search history
- Added utility functions for validation and sanitization
- Added backend routers with full functionality
- Added configuration and type definitions
- Complete documentation and setup guide"

# Create remote
git remote add origin $REPO_URL

# Set main branch
git branch -M main

# Push to GitHub
git push -u origin main

echo "✅ Repository created and pushed successfully!"
echo "📍 Repository URL: $REPO_URL"