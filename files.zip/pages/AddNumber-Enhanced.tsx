import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { useFormValidation } from "@/_core/hooks/useFormValidation";
import {
  validateInput,
  formatPhoneNumber,
  sanitizeString,
} from "@/utils/sanitize";
import { CheckCircle, AlertCircle, Phone, FileText } from "lucide-react";

export default function AddNumber() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const { errors, validate, clearError } = useFormValidation();

  const [phoneNumber, setPhoneNumber] = useState("");
  const [name, setName] = useState("");
  const [category, setCategory] = useState<"spam" | "business" | "personal">(
    "personal"
  );
  const [success, setSuccess] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const addNumberMutation = trpc.numbers.add.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
        <Card className="bg-gray-900 border-gray-700 p-8 text-center max-w-md">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-gray-400 mb-6">You must be logged in to add a number.</p>
          <Link href="/login">
            <a>
              <Button className="bg-white text-black hover:bg-gray-200 w-full">
                Login
              </Button>
            </a>
          </Link>
        </Card>
      </div>
    );
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setPhoneNumber(value);
    clearError("phoneNumber");
  };

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setName(sanitizeString(value, 255));
    clearError("name");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccess("");

    // Validate inputs
    const isValid = validate(
      { phoneNumber, name },
      { phoneNumber: "phone", name: "text" }
    );

    if (!isValid) {
      return;
    }

    const formatted = formatPhoneNumber(phoneNumber);

    setIsLoading(true);
    try {
      await addNumberMutation.mutateAsync({
        phoneNumber: formatted,
        name,
        category,
      });

      setSuccess("Phone number added successfully!");
      setTimeout(() => {
        setLocation("/");
      }, 2000);
    } catch (err: any) {
      errors.submit = err.message || "Failed to add number";
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Navigation */}
      <nav className="border-b border-gray-800 py-4 sticky top-0 bg-black/95 z-40">
        <div className="max-w-6xl mx-auto px-4 flex justify-between items-center">
          <Link href="/">
            <a className="text-2xl font-bold hover:text-gray-300 transition">GET THAT ID</a>
          </Link>
          <Link href="/">
            <Button variant="outline">Back to Home</Button>
          </Link>
        </div>
      </nav>

      {/* Add Number Form */}
      <div className="flex-1 flex items-center justify-center py-20 px-4">
        <Card className="bg-gray-900 border-gray-700 p-8 w-full max-w-md">
          <div className="flex items-center gap-3 mb-6">
            <Phone size={28} className="text-blue-500" />
            <h1 className="text-3xl font-bold">Add Phone Number</h1>
          </div>

          {success && (
            <div className="mb-6 bg-green-900/20 border border-green-700 rounded p-4 flex items-center gap-3 text-green-200">
              <CheckCircle size={20} />
              <div>
                <p className="font-semibold">{success}</p>
                <p className="text-sm">Redirecting...</p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Phone Number */}
            <div>
              <label className="block text-sm font-medium mb-2">
                Phone Number *
              </label>
              <Input
                type="tel"
                value={phoneNumber}
                onChange={handlePhoneChange}
                placeholder="(123) 456-7890"
                className={`bg-gray-800 border-gray-700 text-white ${
                  errors.phoneNumber ? "border-red-500" : ""
                }`}
              />
              {errors.phoneNumber && (
                <p className="text-red-500 text-sm mt-1 flex items-center gap-1">
                  <AlertCircle size={14} />
                  {errors.phoneNumber}
                </p>
              )}
            </div>

            {/* Name / Description */}
            <div>
              <label className="block text-sm font-medium mb-2">
                Name / Description *
              </label>
              <textarea
                value={name}
                onChange={(e) => handleNameChange({ target: { value: e.target.value } } as any)}
                placeholder="e.g., Pizza Place, Spam Caller, Friend John"
                rows={3}
                maxLength={255}
                className={`w-full bg-gray-800 border border-gray-700 text-white rounded px-3 py-2 resize-none ${
                  errors.name ? "border-red-500" : ""
                }`}
              />
              <div className="flex justify-between items-center mt-1">
                {errors.name && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle size={14} />
                    {errors.name}
                  </p>
                )}
                <p className="text-gray-400 text-sm">
                  {name.length}/255
                </p>
              </div>
            </div>

            {/* Category */}
            <div>
              <label className="block text-sm font-medium mb-2">
                Category
              </label>
              <select
                value={category}
                onChange={(e) =>
                  setCategory(e.target.value as any)
                }
                className="w-full bg-gray-800 border border-gray-700 text-white rounded px-3 py-2 focus:border-blue-500 outline-none transition"
              >
                <option value="personal">Personal</option>
                <option value="business">Business</option>
                <option value="spam">Spam</option>
              </select>
              <p className="text-gray-400 text-sm mt-2">
                Help others identify this number correctly
              </p>
            </div>

            {/* Error */}
            {errors.submit && (
              <div className="bg-red-900/20 border border-red-700 rounded p-3 flex items-center gap-2 text-red-200">
                <AlertCircle size={16} />
                {errors.submit}
              </div>
            )}

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isLoading || success}
              className="w-full bg-white text-black hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                "Adding..."
              ) : success ? (
                <>
                  <CheckCircle size={16} className="mr-2" />
                  Added Successfully!
                </>
              ) : (
                <>
                  <FileText size={16} className="mr-2" />
                  Add Number
                </>
              )}
            </Button>
          </form>

          <p className="text-center text-gray-400 mt-6 text-sm">
            Want to search instead?{" "}
            <Link href="/">
              <a className="text-white underline hover:text-gray-300 font-semibold">
                Go back
              </a>
            </Link>
          </p>
        </Card>
      </div>
    </div>
  );
}