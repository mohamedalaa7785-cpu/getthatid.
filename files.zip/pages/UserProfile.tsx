import { useAuth } from "@/_core/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { useState } from "react";
import {
  User,
  Trophy,
  TrendingUp,
  LogOut,
  Edit2,
  CheckCircle,
  AlertCircle,
} from "lucide-react";

export default function UserProfile() {
  const { user, isAuthenticated } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(user?.name || "");
  const [editPhone, setEditPhone] = useState(user?.phone || "");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const reputationQuery = trpc.reputation.getReputation.useQuery(
    { userId: user?.id || 0 },
    { enabled: isAuthenticated && !!user }
  );

  const badgeQuery = trpc.reputation.getBadge.useQuery(
    { userId: user?.id || 0 },
    { enabled: isAuthenticated && !!user }
  );

  const updateProfileMutation = trpc.auth.updateProfile.useMutation();
  const utils = trpc.useUtils();

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    try {
      await updateProfileMutation.mutateAsync({
        name: editName || undefined,
        phone: editPhone || undefined,
      });
      setSuccess("Profile updated successfully");
      setIsEditing(false);
      utils.auth.me.invalidate();
    } catch (err: any) {
      setError(err.message || "Failed to update profile");
    }
  };

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
        <Card className="bg-gray-900 border-gray-700 p-8 text-center max-w-md">
          <p className="text-gray-400 mb-6">Please login to view your profile</p>
          <Link href="/login">
            <a>
              <Button className="bg-white text-black hover:bg-gray-200 w-full">
                Login
              </Button>
            </a>
          </Link>
        </Card>
      </div>
    );
  }

  const getBadgeColor = (badge?: string) => {
    switch (badge) {
      case "expert":
        return "bg-yellow-900 text-yellow-200";
      case "trusted":
        return "bg-blue-900 text-blue-200";
      case "contributor":
        return "bg-green-900 text-green-200";
      default:
        return "bg-gray-700 text-gray-200";
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <nav className="border-b border-gray-800 py-4 sticky top-0 bg-black/95 z-40">
        <div className="max-w-6xl mx-auto px-4 flex justify-between items-center">
          <Link href="/">
            <a className="text-2xl font-bold hover:text-gray-300 transition">GET THAT ID</a>
          </Link>
          <div className="flex gap-4">
            <Link href="/">
              <Button variant="outline" size="sm">
                Back to Home
              </Button>
            </Link>
            <Link href="/logout">
              <Button
                variant="destructive"
                size="sm"
                className="flex items-center gap-2"
              >
                <LogOut size={16} />
                Logout
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="flex-1 max-w-4xl mx-auto w-full py-12 px-4">
        <h1 className="text-4xl font-bold mb-8">Your Profile</h1>

        {/* User Info Card */}
        <Card className="bg-gray-900 border-gray-700 p-6 md:p-8 mb-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                <User size={40} className="text-white" />
              </div>
              <div>
                <h2 className="text-3xl font-bold">{user.name || "User"}</h2>
                <p className="text-gray-400 font-mono">{user.email}</p>
                {user.phone && <p className="text-gray-400">{user.phone}</p>}
                <p className="text-sm text-gray-500 mt-2">
                  Member since {new Date(user.createdAt).toLocaleDateString()}
                </p>
              </div>
            </div>
            {!isEditing && (
              <Button
                onClick={() => setIsEditing(true)}
                className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2 w-full md:w-auto"
              >
                <Edit2 size={16} />
                Edit Profile
              </Button>
            )}
          </div>
        </Card>

        {/* Edit Profile Form */}
        {isEditing && (
          <Card className="bg-gray-900 border-gray-700 p-6 md:p-8 mb-8">
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Name</label>
                <Input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  placeholder="Your name"
                  className="bg-gray-800 border-gray-700"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Phone</label>
                <Input
                  value={editPhone}
                