import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import {
  Search,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Flag,
  Loader,
  Heart,
} from "lucide-react";
import SearchSuggestions from "@/components/SearchSuggestions";
import TrendingNumbers from "@/components/TrendingNumbers";
import { NumberSkeleton } from "@/components/SkeletonLoader";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [phoneNumber, setPhoneNumber] = useState("");
  const [searchResults, setSearchResults] = useState<any>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState("");
  const [showTrending, setShowTrending] = useState(false);

  const utils = trpc.useUtils();

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSearchResults(null);
    setShowTrending(false);

    if (!phoneNumber.trim()) {
      setError("Please enter a phone number");
      return;
    }

    setIsSearching(true);
    try {
      const result = await utils.numbers.search.fetch({ phoneNumber });
      setSearchResults(result);
    } catch (err: any) {
      setError(err.message || "Search failed");
      setSearchResults(null);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSuggestionSelect = (selectedPhoneNumber: string) => {
    setPhoneNumber(selectedPhoneNumber);
    setIsSearching(true);
    setShowTrending(false);

    utils.numbers.search
      .fetch({ phoneNumber: selectedPhoneNumber })
      .then((result) => {
        setSearchResults(result);
        setError("");
      })
      .catch((err: any) => {
        setError(err.message || "Search failed");
        setSearchResults(null);
      })
      .finally(() => setIsSearching(false));
  };

  const handleTrendingSelect = (number: any) => {
    setPhoneNumber(number.phoneNumber);
    setSearchResults({
      found: true,
      data: number,
    });
    setShowTrending(false);
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Navigation */}
      <nav className="border-b border-gray-800 py-4 sticky top-0 bg-black/95 backdrop-blur z-40">
        <div className="max-w-6xl mx-auto px-4 flex justify-between items-center">
          <Link href="/">
            <a className="text-2xl font-bold hover:text-gray-300 transition">GET THAT ID</a>
          </Link>
          <div className="flex gap-4 md:gap-6 items-center text-sm md:text-base">
            <Link href="/" className="hover:text-gray-400 transition">
              HOME
            </Link>
            <Link href="/privacy" className="hover:text-gray-400 transition">
              PRIVACY
            </Link>
            <Link href="/terms" className="hover:text-gray-400 transition">
              TERMS
            </Link>
            {isAuthenticated ? (
              <>
                <Link href="/profile" className="hover:text-gray-400 transition">
                  PROFILE
                </Link>
                {user?.role === "admin" && (
                  <Link href="/admin" className="hover:text-gray-400 transition">
                    ADMIN
                  </Link>
                )}
                <Link href="/logout" className="text-red-500 hover:text-red-400 transition">
                  LOGOUT
                </Link>
              </>
            ) : (
              <>
                <Link href="/login" className="hover:text-gray-400 transition">
                  LOGIN
                </Link>
                <Link href="/signup" className="bg-white text-black px-4 py-2 rounded hover:bg-gray-200 transition">
                  SIGN UP
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="flex-1 flex flex-col items-center justify-center py-16 md:py-20 px-4">
        <div className="text-center mb-8 md:mb-12">
          <p className="text-gray-500 text-sm mb-4">BY HAMO</p>
          <h1 className="text-4xl md:text-6xl font-bold mb-4 md:mb-6">Get That ID</h1>
          <p className="text-gray-400 text-base md:text-lg max-w-2xl mx-auto">
            Identify unknown callers. Report spam. Protect your phone. The premium caller
            identification service.
          </p>
        </div>

        {/* Search Box */}
        <form onSubmit={handleSearch} className="w-full max-w-2xl px-4 mb-8 md:mb-12">
          <div className="flex gap-2 mb-4 flex-col md:flex-row">
            <div className="flex-1 relative">
              <div className="absolute left-3 top-3 text-gray-500 pointer-events-none">
                <Search size={20} />
              </div>
              <SearchSuggestions onSelect={handleSuggestionSelect} />
            </div>
            <Button
              type="submit"
              disabled={isSearching || !phoneNumber.trim()}
              className="bg-white text-black hover:bg-gray-200 px-6 md:px-8 flex items-center justify-center gap-2 w-full md:w-auto"
            >
              {isSearching ? (
                <>
                  <Loader size={16} className="animate-spin" />
                  <span className="hidden sm:inline">Searching...</span>
                </>
              ) : (
                "LOOK UP"
              )}
            </Button>
          </div>
          {error && (
            <div className="text-red-500 text-sm bg-red-900/20 border border-red-700 rounded p-3 flex items-center gap-2">
              <AlertTriangle size={16} />
              {error}
            </div>
          )}
        </form>

        {/* Loading State */}
        {isSearching && <NumberSkeleton />}

        {/* Search Results */}
        {searchResults && !isSearching && (
          <div className="w-full max-w-2xl px-4 mb-8 md:mb-12">
            {searchResults.found ? (
              <SearchResultCard data={searchResults.data} isAuthenticated={isAuthenticated} />
            ) : (
              <Card className="bg-gray-900 border-gray-700 p-6 text-center">
                <AlertTriangle className="mx-auto mb-4 text-gray-500" size={48} />
                <h3 className="text-xl font-bold mb-2">Number Not Found</h3>
                <p className="text-gray-400 mb-6">
                  This phone number is not in our database yet.
                </p>
                {isAuthenticated ? (
                  <Link href={`/add-number?phone=${phoneNumber}`}>
                    <Button className="bg-white text-black hover:bg-gray-200">
                      Add This Number
                    </Button>
                  </Link>
                ) : (
                  <Link href="/login">
                    <Button className="bg-white text-black hover:bg-gray-200">
                      Login to Add Numbers
                    </Button>
                  </Link>
                )}
              </Card>
            )}
          </div>
        )}

        {/* Trending Numbers */}
        {!searchResults && !isSearching && (
          <div className="w-full max-w-2xl px-4 mb-8 md:mb-12">
            <TrendingNumbers onSelect={handleTrendingSelect} />
          </div>
        )}
      </div>

      {/* Features Section */}
      <div className="bg-gray-900 py-16 md:py-20">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Why Get That ID
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 md:gap-8">
            {[
              {
                icon: Search,
                title: "Instant Lookup",
                desc: "Search any phone number and get instant identification results.",
              },
              {
                icon: AlertTriangle,
                title: "Spam Protection",
                desc: "Community-powered spam detection keeps you safe.",
              },
              {
                icon: CheckCircle,
                title: "Community Labels",
                desc: "Verified labels from real users help you decide.",
              },
              {
                icon: Flag,
                title: "Report & Block",
                desc: "Report spam and protect the community.",
              },
            ].map((feature, i) => (
              <div key={i} className="text-center">
                <feature.icon className="mx-auto mb-4 text-gray-500" size={32} />
                <h3 className="font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-16 md:py-20">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                num: "01",
                title: "Enter Number",
                desc: "Type any phone number into our search bar.",
              },
              {
                num: "02",
                title: "Get Results",
                desc: "See caller identity, community labels & reports.",
              },
              {
                num: "03",
                title: "Take Action",
                desc: "Report spam or add your own identification.",
              },
            ].map((step, i) => (
              <div key={i} className="text-center">
                <div className="text-5xl font-bold text-gray-700 mb-4">{step.num}</div>
                <h4 className="text-xl font-bold mb-2">{step.title}</h4>
                <p className="text-gray-400">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-12 bg-gray-950 mt-auto">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">GET THAT ID</h4>
              <p className="text-gray-400 text-sm">
                Premium caller identification by HAMO.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">QUICK LINKS</h4>
              <ul className="text-gray-400 text-sm space-y-2">
                {[
                  { href: "/", label: "Home" },
                  { href: "/privacy", label: "Privacy" },
                  { href: "/terms", label: "Terms" },
                ].map((link) => (
                  <li key={link.href}>
                    <Link href={link.href}>
                      <a className="hover:text-white transition">{link.label}</a>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">CONTACT</h4>
              <a href="mailto:contact@getthatid.com" className="text-gray-400 text-sm hover:text-white transition block">
                contact@getthatid.com
              </a>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-500 text-sm">
            <p>© 2026 Get That ID — by HAMO. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function SearchResultCard({
  data,
  isAuthenticated,
}: {
  data: any;
  isAuthenticated: boolean;
}) {
  const [currentAction, setCurrentAction] = useState<string | null>(null);
  const setActionMutation = trpc.interactions.setAction.useMutation();
  const utils = trpc.useUtils();

  const handleAction = async (action: "agree" | "disagree" | "report") => {
    if (!isAuthenticated) {
      alert("Please login to interact with this number");
      return;
    }

    try {
      await setActionMutation.mutateAsync({ numberId: data.id, action });
      setCurrentAction(action);
      utils.interactions.getByNumber.invalidate({ numberId: data.id });
      utils.numbers.search.invalidate();
    } catch (error) {
      console.error("Failed to record action:", error);
      alert("Failed to record your action");
    }
  };

  return (
    <Card className="bg-gray-900 border-gray-700 p-6">
      <div className="mb-6">
        <h2 className="text-2xl md:text-3xl font-bold mb-2">{data.name}</h2>
        <p className="text-gray-400 font-mono">{data.phoneNumber}</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-gray-800 p-4 rounded">
          <p className="text-gray-400 text-sm mb-1">Category</p>
          <p className="text-lg md:text-xl font-bold capitalize">{data.category}</p>
        </div>
        <div className="bg-gray-800 p-4 rounded">
          <p className="text-gray-400 text-sm mb-1">Agree</p>
          <p className="text-lg md:text-xl font-bold text-green-500">{data.agreeCount}</p>
        </div>
        <div className="bg-gray-800 p-4 rounded">
          <p className="text-gray-400 text-sm mb-1">Disagree</p>
          <p className="text-lg md:text-xl font-bold text-red-500">{data.disagreeCount}</p>
        </div>
      </div>

      <div className="bg-gray-800 p-4 rounded mb-6">
        <p className="text-gray-400 text-sm mb-1">Reports</p>
        <p className="text-lg md:text-xl font-bold text-yellow-500">{data.reportCount}</p>
      </div>

      {isAuthenticated ? (
        <div className="flex gap-2 flex-col md:flex-row">
          {[
            {
              action: "agree" as const,
              icon: Heart,
              label: "Agree",
              color: "bg-green-600 hover:bg-green-700",
            },
            {
              action: "disagree" as const,
              icon: XCircle,
              label: "Disagree",
              color: "bg-red-600 hover:bg-red-700",
            },
            {
              action: "report" as const,
              icon: Flag,
              label: "Report",
              color: "bg-yellow-600 hover:bg-yellow-700",
            },
          ].map((btn) => (
            <Button
              key={btn.action}
              onClick={() => handleAction(btn.action)}
              disabled={setActionMutation.isPending}
              className={`flex-1 ${
                currentAction === btn.action ? btn.color : "bg-gray-700 hover:bg-gray-600"
              }`}
            >
              <btn.icon size={16} className="mr-2" />
              {btn.label}
            </Button>
          ))}
        </div>
      ) : (
        <div className="bg-blue-900 border border-blue-700 p-4 rounded">
          <p className="text-blue-200 text-center">
            <Link href="/login">
              <a className="underline hover:text-blue-100 font-semibold">Sign in</a>
            </Link>
            {" "}to interact with this number
          </p>
        </div>
      )}
    </Card>
  );
}