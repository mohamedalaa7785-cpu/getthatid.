import { useState } from "react";
import { validateInput } from "@/utils/sanitize";

export function useFormValidation() {
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = (
    values: Record<string, string>,
    types: Record<string, "email" | "phone" | "text" | "password">
  ): boolean => {
    const newErrors: Record<string, string> = {};

    for (const [field, type] of Object.entries(types)) {
      const result = validateInput(values[field] || "", type);
      if (!result.valid && result.error) {
        newErrors[field] = result.error;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const clearError = (field: string) => {
    setErrors((prev) => {
      const next = { ...prev };
      delete next[field];
      return next;
    });
  };

  return { errors, validate, clearError, setErrors };
}