import { useEffect, useState } from "react";

const STORAGE_KEY = "searchHistory";

export function useSearchHistory() {
  const [history, setHistory] = useState<string[]>([]);

  // Load history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load search history");
      }
    }
  }, []);

  const addSearch = (phoneNumber: string) => {
    const updated = [
      phoneNumber,
      ...history.filter((h) => h !== phoneNumber),
    ].slice(0, 10);
    setHistory(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem(STORAGE_KEY);
  };

  const removeSearch = (phoneNumber: string) => {
    const updated = history.filter((h) => h !== phoneNumber);
    setHistory(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  return { history, addSearch, clearHistory, removeSearch };
}