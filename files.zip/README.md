# 🎯 Get That ID - Phone Lookup App

[![GitHub](https://img.shields.io/badge/GitHub-Get_That_ID-blue?logo=github)](https://github.com/mohamedalaa7785-cpu/Get-That-ID-Phone-Lookup-App)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Version](https://img.shields.io/badge/Version-1.0.0-orange.svg)](package.json)

**Premium caller identification service** - Identify unknown callers, report spam, protect your phone.

---

## ✨ Features

### 🔍 **Search & Discovery**
- Real-time phone number search with autocomplete
- Recent search history (automatically saved)
- Advanced search with category filters
- Trending numbers widget
- Server-side pagination

### 👤 **User Management**
- User registration and login
- User profile with reputation score
- Edit profile information
- Reputation and accuracy rating
- Activity tracking

### 📊 **Admin Dashboard**
- Comprehensive statistics
- Interactive charts (categories, interactions)
- Phone number management
- User management with blocking
- Data export (CSV/JSON)
- Pagination for all tables

### 🛡️ **Security**
- Input validation and sanitization
- Password strength validation
- Rate limiting
- Activity logging
- Error boundary handling
- Role-based access control

### 📱 **UI/UX**
- Fully responsive design (mobile-first)
- Dark theme with modern design
- Loading skeletons
- Toast notifications
- Error handling
- Smooth animations

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn

### Installation

```bash
# Clone the repository
git clone https://github.com/mohamedalaa7785-cpu/Get-That-ID-Phone-Lookup-App.git
cd Get-That-ID-Phone-Lookup-App

# Install dependencies
npm install

# Setup environment
cp .env.example .env.local
# Edit .env.local with your configuration

# Start development server
npm run dev