#!/bin/bash

echo "🔧 Fixing Vercel NOT_FOUND Error..."

# 1. Clean build
rm -rf dist node_modules
npm install

# 2. Type check
npm run type-check

# 3. Build
npm run build

# 4. Preview locally
npm run preview &

echo "✅ Local preview running on http://localhost:4173"
echo ""
echo "Next steps:"
echo "1. Test the URLs that were giving 404"
echo "2. If working locally, issue is in Vercel config"
echo "3. Check vercel.json and environment variables"
echo "4. Push to GitHub and check Vercel Dashboard"

# Kill preview
wait